-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2021 at 11:50 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `worldpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `ap_commentmeta`
--

CREATE TABLE `ap_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ap_comments`
--

CREATE TABLE `ap_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_comments`
--

INSERT INTO `ap_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2021-06-11 12:51:00', '2021-06-11 12:51:00', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ap_links`
--

CREATE TABLE `ap_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ap_options`
--

CREATE TABLE `ap_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_options`
--

INSERT INTO `ap_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wp', 'yes'),
(2, 'home', 'http://localhost/wp', 'yes'),
(3, 'blogname', 'Ganesha', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'ruchipatel3170@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:94:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:17:\"^wp-sitemap\\.xml$\";s:23:\"index.php?sitemap=index\";s:17:\"^wp-sitemap\\.xsl$\";s:36:\"index.php?sitemap-stylesheet=sitemap\";s:23:\"^wp-sitemap-index\\.xsl$\";s:34:\"index.php?sitemap-stylesheet=index\";s:48:\"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$\";s:75:\"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]\";s:34:\"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$\";s:47:\"index.php?sitemap=$matches[1]&paged=$matches[2]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:53:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$\";s:91:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:61:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:53:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:4:{i:0;s:57:\"C:\\xampp\\htdocs\\wp/wp-content/themes/enjoynews/header.php\";i:1;s:56:\"C:\\xampp\\htdocs\\wp/wp-content/themes/enjoynews/style.css\";i:2;s:59:\"C:\\xampp\\htdocs\\wp/wp-content/themes/twentytwenty/style.css\";i:3;s:0:\"\";}', 'no'),
(40, 'template', 'twentytwenty', 'yes'),
(41, 'stylesheet', 'twentytwenty', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '49752', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:2:{i:0;i:87;i:1;i:145;}', 'yes'),
(76, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(77, 'widget_text', 'a:3:{i:2;a:4:{s:5:\"title\";s:15:\"About This Site\";s:4:\"text\";s:85:\"This may be a good place to introduce yourself and your site or include some credits.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}i:3;a:4:{s:5:\"title\";s:7:\"Find Us\";s:4:\"text\";s:168:\"<strong>Address</strong>\n123 Main Street\nNew York, NY 10001\n\n<strong>Hours</strong>\nMonday&ndash;Friday: 9:00AM&ndash;5:00PM\nSaturday &amp; Sunday: 11:00AM&ndash;3:00PM\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '65', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1638967851', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'initial_db_version', '49752', 'yes'),
(99, 'ap_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(100, 'fresh_site', '0', 'yes'),
(101, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'sidebars_widgets', 'a:11:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:12:\"home-content\";a:0:{}s:12:\"home-sidebar\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:9:\"header-ad\";a:0:{}s:10:\"archive-ad\";a:0:{}s:13:\"array_version\";i:3;}', 'yes'),
(107, 'cron', 'a:7:{i:1623577863;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1623588662;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1623588663;a:4:{s:18:\"wp_https_detection\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1623588682;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1623588688;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1624107062;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(114, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(116, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(118, 'recovery_keys', 'a:0:{}', 'yes'),
(119, 'theme_mods_twentytwentyone', 'a:4:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1623563345;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}}}s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:23;}s:25:\"display_title_and_tagline\";b:0;}', 'yes'),
(120, 'https_detection_errors', 'a:1:{s:23:\"ssl_verification_failed\";a:1:{i:0;s:24:\"SSL verification failed.\";}}', 'yes'),
(121, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.7.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.7.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.7.2-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:5:\"5.7.2\";s:7:\"version\";s:5:\"5.7.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1623573503;s:15:\"version_checked\";s:5:\"5.7.2\";s:12:\"translations\";a:0:{}}', 'no'),
(127, '_site_transient_timeout_browser_3a19c5b2ea764b667094aa0ea89035cb', '1624020683', 'no'),
(128, '_site_transient_browser_3a19c5b2ea764b667094aa0ea89035cb', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"91.0.4472.77\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(129, '_site_transient_timeout_php_check_3dbf48b9658abaee82651209c2ca7be3', '1624020686', 'no'),
(130, '_site_transient_php_check_3dbf48b9658abaee82651209c2ca7be3', 'a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(134, 'can_compress_scripts', '1', 'no'),
(147, 'finished_updating_comment_type', '1', 'yes'),
(191, 'theme_mods_twentytwenty', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:25;}}', 'yes'),
(194, 'current_theme', 'Twenty Twenty', 'yes'),
(195, 'theme_switched', '', 'yes'),
(197, '_transient_health-check-site-status-result', '{\"good\":\"12\",\"recommended\":\"7\",\"critical\":\"1\"}', 'yes'),
(198, '_transient_timeout_oembed_66764b82c8e740b811a189f38ca1bb0c', '1623589120', 'no'),
(199, '_transient_oembed_66764b82c8e740b811a189f38ca1bb0c', 'O:8:\"stdClass\":13:{s:5:\"title\";s:105:\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\";s:11:\"author_name\";s:10:\"ABP Asmita\";s:10:\"author_url\";s:37:\"https://www.youtube.com/c/ABPAsmitaTV\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/Z-KyhfqjYrE/hqdefault.jpg\";s:4:\"html\";s:348:\"<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(203, '_site_transient_update_themes', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1623573500;s:7:\"checked\";a:4:{s:9:\"enjoynews\";s:5:\"1.1.1\";s:14:\"twentynineteen\";s:3:\"2.0\";s:12:\"twentytwenty\";s:3:\"1.7\";s:15:\"twentytwentyone\";s:3:\"1.3\";}s:8:\"response\";a:1:{s:9:\"enjoynews\";a:6:{s:5:\"theme\";s:9:\"enjoynews\";s:11:\"new_version\";s:5:\"1.1.2\";s:3:\"url\";s:39:\"https://wordpress.org/themes/enjoynews/\";s:7:\"package\";s:57:\"https://downloads.wordpress.org/theme/enjoynews.1.1.2.zip\";s:8:\"requires\";s:3:\"4.9\";s:12:\"requires_php\";s:3:\"5.6\";}}s:9:\"no_update\";a:3:{s:14:\"twentynineteen\";a:6:{s:5:\"theme\";s:14:\"twentynineteen\";s:11:\"new_version\";s:3:\"2.0\";s:3:\"url\";s:44:\"https://wordpress.org/themes/twentynineteen/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/theme/twentynineteen.2.0.zip\";s:8:\"requires\";s:5:\"4.9.6\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.7\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.7.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}s:15:\"twentytwentyone\";a:6:{s:5:\"theme\";s:15:\"twentytwentyone\";s:11:\"new_version\";s:3:\"1.3\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentytwentyone/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentytwentyone.1.3.zip\";s:8:\"requires\";s:3:\"5.3\";s:12:\"requires_php\";s:3:\"5.6\";}}s:12:\"translations\";a:0:{}}', 'no'),
(206, 'widget_enjoynews-most-commented', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(207, 'widget_enjoynews-recent', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(208, 'widget_enjoynews-category-posts', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(209, 'widget_enjoynews-home-content', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(212, '_site_transient_timeout_community-events-d41d8cd98f00b204e9800998ecf8427e', '1623617243', 'no'),
(213, '_site_transient_community-events-d41d8cd98f00b204e9800998ecf8427e', 'a:4:{s:9:\"sandboxed\";b:0;s:5:\"error\";N;s:8:\"location\";a:1:{s:2:\"ip\";b:0;}s:6:\"events\";a:2:{i:0;a:10:{s:4:\"type\";s:6:\"meetup\";s:5:\"title\";s:71:\"Watch Party + Discussion group: Creating and Registering Block Patterns\";s:3:\"url\";s:68:\"https://www.meetup.com/learn-wordpress-discussions/events/278477212/\";s:6:\"meetup\";s:27:\"Learn WordPress Discussions\";s:10:\"meetup_url\";s:51:\"https://www.meetup.com/learn-wordpress-discussions/\";s:4:\"date\";s:19:\"2021-06-15 11:00:00\";s:8:\"end_date\";s:19:\"2021-06-15 12:00:00\";s:20:\"start_unix_timestamp\";i:1623780000;s:18:\"end_unix_timestamp\";i:1623783600;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"US\";s:8:\"latitude\";d:37.779998779297;s:9:\"longitude\";d:-122.41999816895;}}i:1;a:10:{s:4:\"type\";s:8:\"wordcamp\";s:5:\"title\";s:19:\"WordCamp Japan 2021\";s:3:\"url\";s:32:\"https://japan.wordcamp.org/2021/\";s:6:\"meetup\";N;s:10:\"meetup_url\";N;s:4:\"date\";s:19:\"2021-06-20 00:00:00\";s:8:\"end_date\";s:19:\"2021-06-26 00:00:00\";s:20:\"start_unix_timestamp\";i:1624114800;s:18:\"end_unix_timestamp\";i:1624633200;s:8:\"location\";a:4:{s:8:\"location\";s:6:\"Online\";s:7:\"country\";s:2:\"JP\";s:8:\"latitude\";d:35.6761919;s:9:\"longitude\";d:139.6503106;}}}}', 'no'),
(217, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(230, '_transient_timeout_dash_v2_88ae138922fe95674369b1cb3d215a2b', '1623604697', 'no'),
(231, '_transient_dash_v2_88ae138922fe95674369b1cb3d215a2b', '<div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: A valid URL was not provided.</p></div><div class=\"rss-widget\"><p><strong>RSS Error:</strong> WP HTTP Error: A valid URL was not provided.</p></div>', 'no'),
(235, 'theme_mods_enjoynews', 'a:3:{s:18:\"custom_css_post_id\";i:-1;s:18:\"nav_menu_locations\";a:1:{s:7:\"primary\";i:23;}s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1623563602;s:4:\"data\";a:10:{s:19:\"wp_inactive_widgets\";a:2:{i:0;s:6:\"text-2\";i:1;s:6:\"text-3\";}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:12:\"home-content\";a:0:{}s:12:\"home-sidebar\";a:0:{}s:8:\"footer-1\";a:0:{}s:8:\"footer-2\";a:0:{}s:8:\"footer-3\";a:0:{}s:8:\"footer-4\";a:0:{}s:9:\"header-ad\";a:0:{}s:10:\"archive-ad\";a:0:{}}}}', 'yes'),
(239, 'theme_switch_menu_locations', 'a:1:{s:7:\"primary\";i:23;}', 'yes'),
(240, 'theme_switched_via_customizer', '', 'yes'),
(241, 'customize_stashed_theme_mods', 'a:0:{}', 'no'),
(244, 'category_children', 'a:4:{i:3;a:2:{i:0;i:10;i:1;i:11;}i:6;a:1:{i:0;i:12;}i:2;a:1:{i:0;i:13;}i:15;a:2:{i:0;i:16;i:1;i:17;}}', 'yes'),
(251, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1623573507;s:7:\"checked\";a:3:{s:19:\"akismet/akismet.php\";s:5:\"4.1.9\";s:37:\"blogger-importer/blogger-importer.php\";s:3:\"0.9\";s:9:\"hello.php\";s:5:\"1.7.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.9\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.9.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"blogger-importer/blogger-importer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:30:\"w.org/plugins/blogger-importer\";s:4:\"slug\";s:16:\"blogger-importer\";s:6:\"plugin\";s:37:\"blogger-importer/blogger-importer.php\";s:11:\"new_version\";s:3:\"0.9\";s:3:\"url\";s:47:\"https://wordpress.org/plugins/blogger-importer/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/blogger-importer.0.9.zip\";s:5:\"icons\";a:3:{s:2:\"2x\";s:69:\"https://ps.w.org/blogger-importer/assets/icon-256x256.png?rev=1908375\";s:2:\"1x\";s:61:\"https://ps.w.org/blogger-importer/assets/icon.svg?rev=1908375\";s:3:\"svg\";s:61:\"https://ps.w.org/blogger-importer/assets/icon.svg?rev=1908375\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:70:\"https://ps.w.org/blogger-importer/assets/banner-772x250.png?rev=547650\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(262, '_transient_timeout_oembed_40fd6062564bbecc56cd30395afc0546', '1623654735', 'no'),
(263, '_transient_oembed_40fd6062564bbecc56cd30395afc0546', 'O:8:\"stdClass\":13:{s:5:\"title\";s:240:\"ABP Ananda LIVE : মুকুলের তৃণমূলে যোগদান নিয়ে বাগযুদ্ধ দুই শিবিরের, নিউটাউন শ্যুটআউট কাণ্ডে নয়া তথ্য\";s:11:\"author_name\";s:10:\"ABP ANANDA\";s:10:\"author_url\";s:37:\"https://www.youtube.com/c/abpanandatv\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/TpkRThMDClU/hqdefault.jpg\";s:4:\"html\";s:483:\"<iframe title=\"ABP Ananda LIVE : মুকুলের তৃণমূলে যোগদান নিয়ে বাগযুদ্ধ দুই শিবিরের, নিউটাউন শ্যুটআউট কাণ্ডে নয়া তথ্য\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/TpkRThMDClU?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(268, '_transient_timeout_oembed_9c5b8df4c6667bcdd8cb39c8d3cfb8b1', '1623655823', 'no'),
(269, '_transient_oembed_9c5b8df4c6667bcdd8cb39c8d3cfb8b1', 'O:8:\"stdClass\":13:{s:5:\"title\";s:105:\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\";s:11:\"author_name\";s:10:\"ABP Asmita\";s:10:\"author_url\";s:37:\"https://www.youtube.com/c/ABPAsmitaTV\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/Z-KyhfqjYrE/hqdefault.jpg\";s:4:\"html\";s:348:\"<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(275, '_transient_timeout_oembed_03364e4310b2b0e00b182d9e6b90ca57', '1623656338', 'no'),
(276, '_transient_oembed_03364e4310b2b0e00b182d9e6b90ca57', 'O:8:\"stdClass\":13:{s:5:\"title\";s:97:\"COVID-19 Crisis | Monsoon 2021 | Vaccination Campaign | Live Gujarati News |  | TV9 Gujarati LIVE\";s:11:\"author_name\";s:12:\"TV9 Gujarati\";s:10:\"author_url\";s:41:\"https://www.youtube.com/c/TV9GujaratiNews\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:450;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/Mvz3_9O4p4s/hqdefault.jpg\";s:4:\"html\";s:340:\"<iframe title=\"COVID-19 Crisis | Monsoon 2021 | Vaccination Campaign | Live Gujarati News |  | TV9 Gujarati LIVE\" width=\"600\" height=\"450\" src=\"https://www.youtube.com/embed/Mvz3_9O4p4s?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(288, '_transient_timeout_oembed_895f8d1e797fbd265d644204acb29e85', '1623657566', 'no'),
(289, '_transient_oembed_895f8d1e797fbd265d644204acb29e85', 'O:8:\"stdClass\":13:{s:5:\"title\";s:152:\"Hindi News Live: देश-दुनिया की इस वक्त की 100 बड़ी खबरें I Nonstop 100 I Top 100 I June 13, 2021\";s:11:\"author_name\";s:7:\"Aaj Tak\";s:10:\"author_url\";s:32:\"https://www.youtube.com/c/aajtak\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/6giviFF-Hck/hqdefault.jpg\";s:4:\"html\";s:395:\"<iframe title=\"Hindi News Live: देश-दुनिया की इस वक्त की 100 बड़ी खबरें I Nonstop 100 I Top 100 I June 13, 2021\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/6giviFF-Hck?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(295, '_transient_timeout_oembed_d68a584ebfe9bdd4beeb961f65e26e64', '1623658301', 'no'),
(296, '_transient_oembed_d68a584ebfe9bdd4beeb961f65e26e64', 'O:8:\"stdClass\":13:{s:5:\"title\";s:97:\"TV9 Marathi Live | Maharashtra Lockdown | Monsoon Update | Mumbai Rain | Malad Building Collapsed\";s:11:\"author_name\";s:11:\"TV9 Marathi\";s:10:\"author_url\";s:40:\"https://www.youtube.com/c/TV9MarathiLive\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/-Ku6BOxFIkc/hqdefault.jpg\";s:4:\"html\";s:340:\"<iframe title=\"TV9 Marathi Live | Maharashtra Lockdown | Monsoon Update | Mumbai Rain | Malad Building Collapsed\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/-Ku6BOxFIkc?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(299, '_transient_timeout_oembed_8b1935404743b1aec49190850b494511', '1623658442', 'no'),
(300, '_transient_oembed_8b1935404743b1aec49190850b494511', 'O:8:\"stdClass\":13:{s:5:\"title\";s:100:\"ABP Majha LIVE | Maharashtra Monsoon | Mumbai Rains | Maharashtra Unlock | Vaccination |Live TV 24X7\";s:11:\"author_name\";s:9:\"ABP MAJHA\";s:10:\"author_url\";s:36:\"https://www.youtube.com/c/abpmajhatv\";s:4:\"type\";s:5:\"video\";s:6:\"height\";i:338;s:5:\"width\";i:600;s:7:\"version\";s:3:\"1.0\";s:13:\"provider_name\";s:7:\"YouTube\";s:12:\"provider_url\";s:24:\"https://www.youtube.com/\";s:16:\"thumbnail_height\";i:360;s:15:\"thumbnail_width\";i:480;s:13:\"thumbnail_url\";s:48:\"https://i.ytimg.com/vi/I6zGBF72o7M/hqdefault.jpg\";s:4:\"html\";s:343:\"<iframe title=\"ABP Majha LIVE | Maharashtra Monsoon | Mumbai Rains | Maharashtra Unlock | Vaccination |Live TV 24X7\" width=\"600\" height=\"338\" src=\"https://www.youtube.com/embed/I6zGBF72o7M?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\";}', 'no'),
(315, 'core_updater.lock', '1623573563', 'no'),
(317, 'recently_activated', 'a:0:{}', 'yes'),
(320, '_site_transient_timeout_theme_roots', '1623579267', 'no'),
(321, '_site_transient_theme_roots', 'a:4:{s:9:\"enjoynews\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";s:15:\"twentytwentyone\";s:7:\"/themes\";}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `ap_postmeta`
--

CREATE TABLE `ap_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_postmeta`
--

INSERT INTO `ap_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_edit_lock', '1623506995:1'),
(4, 6, '_edit_lock', '1623495542:1'),
(5, 7, '_wp_attached_file', '2021/06/logo.png'),
(6, 7, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:548;s:6:\"height\";i:326;s:4:\"file\";s:16:\"2021/06/logo.png\";s:5:\"sizes\";a:2:{s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"logo-300x178.png\";s:5:\"width\";i:300;s:6:\"height\";i:178;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(8, 10, '_wp_attached_file', '2021/06/image.png'),
(9, 10, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:150;s:6:\"height\";i:150;s:4:\"file\";s:17:\"2021/06/image.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(12, 17, '_edit_lock', '1623500606:1'),
(13, 19, '_wp_attached_file', '2021/06/2020-landscape-1.png'),
(14, 19, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:769;s:4:\"file\";s:28:\"2021/06/2020-landscape-1.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-300x192.png\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:29:\"2020-landscape-1-1024x656.png\";s:5:\"width\";i:1024;s:6:\"height\";i:656;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:28:\"2020-landscape-1-768x492.png\";s:5:\"width\";i:768;s:6:\"height\";i:492;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(15, 19, '_starter_content_theme', 'twentytwenty'),
(16, 19, '_customize_draft_post_name', 'the-new-umoma-opens-its-doors'),
(17, 20, '_thumbnail_id', '19'),
(18, 20, '_customize_draft_post_name', 'the-new-umoma-opens-its-doors'),
(19, 20, '_customize_changeset_uuid', '1a514e3a-1ebb-4439-928a-b78c7c4b3472'),
(20, 21, '_customize_draft_post_name', 'about'),
(21, 21, '_customize_changeset_uuid', '1a514e3a-1ebb-4439-928a-b78c7c4b3472'),
(22, 22, '_customize_draft_post_name', 'contact'),
(23, 22, '_customize_changeset_uuid', '1a514e3a-1ebb-4439-928a-b78c7c4b3472'),
(24, 23, '_customize_draft_post_name', 'blog'),
(25, 23, '_customize_changeset_uuid', '1a514e3a-1ebb-4439-928a-b78c7c4b3472'),
(26, 25, '_edit_lock', '1623506230:1'),
(27, 25, '_oembed_fba81199eff33092c5b6902e96b99800', '<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(28, 25, '_oembed_time_fba81199eff33092c5b6902e96b99800', '1623502743'),
(29, 29, '_wp_attached_file', '2021/06/2020-landscape-1-1.png'),
(30, 29, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1200;s:6:\"height\";i:769;s:4:\"file\";s:30:\"2021/06/2020-landscape-1-1.png\";s:5:\"sizes\";a:4:{s:6:\"medium\";a:4:{s:4:\"file\";s:30:\"2020-landscape-1-1-300x192.png\";s:5:\"width\";i:300;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:5:\"large\";a:4:{s:4:\"file\";s:31:\"2020-landscape-1-1-1024x656.png\";s:5:\"width\";i:1024;s:6:\"height\";i:656;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:30:\"2020-landscape-1-1-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:30:\"2020-landscape-1-1-768x492.png\";s:5:\"width\";i:768;s:6:\"height\";i:492;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(31, 29, '_starter_content_theme', 'twentytwenty'),
(32, 29, '_customize_draft_post_name', 'the-new-umoma-opens-its-doors'),
(33, 30, '_thumbnail_id', '29'),
(34, 30, '_customize_draft_post_name', 'the-new-umoma-opens-its-doors'),
(35, 30, '_customize_changeset_uuid', '740ba3d7-8ea5-425c-ab79-0f856e872d83'),
(36, 31, '_customize_draft_post_name', 'about'),
(37, 31, '_customize_changeset_uuid', '740ba3d7-8ea5-425c-ab79-0f856e872d83'),
(38, 32, '_customize_draft_post_name', 'contact'),
(39, 32, '_customize_changeset_uuid', '740ba3d7-8ea5-425c-ab79-0f856e872d83'),
(40, 33, '_customize_draft_post_name', 'blog'),
(41, 33, '_customize_changeset_uuid', '740ba3d7-8ea5-425c-ab79-0f856e872d83'),
(42, 25, '_oembed_b9cad99a18d20483f30a6df69b9e06c3', '<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"880\" height=\"495\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(43, 25, '_oembed_time_b9cad99a18d20483f30a6df69b9e06c3', '1623503469'),
(44, 5, 'enjoynews-featured', 'yes'),
(45, 5, '_edit_last', '1'),
(48, 5, '_wp_desired_post_slug', ''),
(49, 37, 'enjoynews-featured', 'no'),
(50, 37, '_menu_item_type', 'taxonomy'),
(51, 37, '_menu_item_menu_item_parent', '0'),
(52, 37, '_menu_item_object_id', '6'),
(53, 37, '_menu_item_object', 'category'),
(54, 37, '_menu_item_target', ''),
(55, 37, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(56, 37, '_menu_item_xfn', ''),
(57, 37, '_menu_item_url', ''),
(58, 37, '_menu_item_orphaned', '1623504151'),
(59, 38, 'enjoynews-featured', 'no'),
(60, 38, '_menu_item_type', 'taxonomy'),
(61, 38, '_menu_item_menu_item_parent', '0'),
(62, 38, '_menu_item_object_id', '12'),
(63, 38, '_menu_item_object', 'category'),
(64, 38, '_menu_item_target', ''),
(65, 38, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(66, 38, '_menu_item_xfn', ''),
(67, 38, '_menu_item_url', ''),
(68, 38, '_menu_item_orphaned', '1623504152'),
(69, 39, 'enjoynews-featured', 'no'),
(70, 39, '_menu_item_type', 'taxonomy'),
(71, 39, '_menu_item_menu_item_parent', '0'),
(72, 39, '_menu_item_object_id', '3'),
(73, 39, '_menu_item_object', 'category'),
(74, 39, '_menu_item_target', ''),
(75, 39, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(76, 39, '_menu_item_xfn', ''),
(77, 39, '_menu_item_url', ''),
(78, 39, '_menu_item_orphaned', '1623504153'),
(79, 40, 'enjoynews-featured', 'no'),
(80, 40, '_menu_item_type', 'taxonomy'),
(81, 40, '_menu_item_menu_item_parent', '0'),
(82, 40, '_menu_item_object_id', '11'),
(83, 40, '_menu_item_object', 'category'),
(84, 40, '_menu_item_target', ''),
(85, 40, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(86, 40, '_menu_item_xfn', ''),
(87, 40, '_menu_item_url', ''),
(88, 40, '_menu_item_orphaned', '1623504154'),
(89, 41, 'enjoynews-featured', 'no'),
(90, 41, '_menu_item_type', 'taxonomy'),
(91, 41, '_menu_item_menu_item_parent', '0'),
(92, 41, '_menu_item_object_id', '10'),
(93, 41, '_menu_item_object', 'category'),
(94, 41, '_menu_item_target', ''),
(95, 41, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(96, 41, '_menu_item_xfn', ''),
(97, 41, '_menu_item_url', ''),
(98, 41, '_menu_item_orphaned', '1623504156'),
(99, 42, 'enjoynews-featured', 'no'),
(100, 42, '_menu_item_type', 'taxonomy'),
(101, 42, '_menu_item_menu_item_parent', '0'),
(102, 42, '_menu_item_object_id', '2'),
(103, 42, '_menu_item_object', 'category'),
(104, 42, '_menu_item_target', ''),
(105, 42, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(106, 42, '_menu_item_xfn', ''),
(107, 42, '_menu_item_url', ''),
(108, 42, '_menu_item_orphaned', '1623504157'),
(109, 43, 'enjoynews-featured', 'no'),
(110, 43, '_menu_item_type', 'taxonomy'),
(111, 43, '_menu_item_menu_item_parent', '0'),
(112, 43, '_menu_item_object_id', '13'),
(113, 43, '_menu_item_object', 'category'),
(114, 43, '_menu_item_target', ''),
(115, 43, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(116, 43, '_menu_item_xfn', ''),
(117, 43, '_menu_item_url', ''),
(118, 43, '_menu_item_orphaned', '1623504158'),
(119, 44, 'enjoynews-featured', 'no'),
(120, 44, '_menu_item_type', 'taxonomy'),
(121, 44, '_menu_item_menu_item_parent', '0'),
(122, 44, '_menu_item_object_id', '15'),
(123, 44, '_menu_item_object', 'category'),
(124, 44, '_menu_item_target', ''),
(125, 44, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(126, 44, '_menu_item_xfn', ''),
(127, 44, '_menu_item_url', ''),
(128, 44, '_menu_item_orphaned', '1623504159'),
(129, 45, 'enjoynews-featured', 'no'),
(130, 45, '_menu_item_type', 'taxonomy'),
(131, 45, '_menu_item_menu_item_parent', '0'),
(132, 45, '_menu_item_object_id', '16'),
(133, 45, '_menu_item_object', 'category'),
(134, 45, '_menu_item_target', ''),
(135, 45, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(136, 45, '_menu_item_xfn', ''),
(137, 45, '_menu_item_url', ''),
(138, 45, '_menu_item_orphaned', '1623504160'),
(139, 46, 'enjoynews-featured', 'no'),
(140, 46, '_menu_item_type', 'taxonomy'),
(141, 46, '_menu_item_menu_item_parent', '0'),
(142, 46, '_menu_item_object_id', '17'),
(143, 46, '_menu_item_object', 'category'),
(144, 46, '_menu_item_target', ''),
(145, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(146, 46, '_menu_item_xfn', ''),
(147, 46, '_menu_item_url', ''),
(148, 46, '_menu_item_orphaned', '1623504161'),
(149, 47, 'enjoynews-featured', 'no'),
(150, 47, '_menu_item_type', 'taxonomy'),
(151, 47, '_menu_item_menu_item_parent', '0'),
(152, 47, '_menu_item_object_id', '9'),
(153, 47, '_menu_item_object', 'category'),
(154, 47, '_menu_item_target', ''),
(155, 47, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(156, 47, '_menu_item_xfn', ''),
(157, 47, '_menu_item_url', ''),
(158, 47, '_menu_item_orphaned', '1623504162'),
(159, 48, 'enjoynews-featured', 'no'),
(160, 48, '_menu_item_type', 'taxonomy'),
(161, 48, '_menu_item_menu_item_parent', '0'),
(162, 48, '_menu_item_object_id', '1'),
(163, 48, '_menu_item_object', 'category'),
(164, 48, '_menu_item_target', ''),
(165, 48, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(166, 48, '_menu_item_xfn', ''),
(167, 48, '_menu_item_url', ''),
(168, 48, '_menu_item_orphaned', '1623504163'),
(270, 60, '_customize_changeset_uuid', 'e2e02643-f672-4874-a8f8-f65be05d4dee'),
(272, 61, '_customize_changeset_uuid', 'e2e02643-f672-4874-a8f8-f65be05d4dee'),
(274, 62, '_customize_changeset_uuid', 'e2e02643-f672-4874-a8f8-f65be05d4dee'),
(276, 63, '_customize_changeset_uuid', 'e2e02643-f672-4874-a8f8-f65be05d4dee'),
(277, 65, '_wp_attached_file', '2021/06/cropped-logo.png'),
(278, 65, '_wp_attachment_context', 'site-icon'),
(279, 65, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:512;s:6:\"height\";i:512;s:4:\"file\";s:24:\"2021/06/cropped-logo.png\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"cropped-logo-300x300.png\";s:5:\"width\";i:300;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"cropped-logo-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-270\";a:4:{s:4:\"file\";s:24:\"cropped-logo-270x270.png\";s:5:\"width\";i:270;s:6:\"height\";i:270;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-192\";a:4:{s:4:\"file\";s:24:\"cropped-logo-192x192.png\";s:5:\"width\";i:192;s:6:\"height\";i:192;s:9:\"mime-type\";s:9:\"image/png\";}s:13:\"site_icon-180\";a:4:{s:4:\"file\";s:24:\"cropped-logo-180x180.png\";s:5:\"width\";i:180;s:6:\"height\";i:180;s:9:\"mime-type\";s:9:\"image/png\";}s:12:\"site_icon-32\";a:4:{s:4:\"file\";s:22:\"cropped-logo-32x32.png\";s:5:\"width\";i:32;s:6:\"height\";i:32;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(376, 64, '_wp_trash_meta_status', 'publish'),
(377, 64, '_wp_trash_meta_time', '1623504966'),
(378, 1, '_edit_lock', '1623505440:1'),
(379, 25, '_oembed_7032635fe3bc8ceb9cf513c72a0e847c', '<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"750\" height=\"422\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(380, 25, '_oembed_time_7032635fe3bc8ceb9cf513c72a0e847c', '1623506327'),
(381, 34, '_customize_restore_dismissed', '1'),
(382, 24, '_customize_restore_dismissed', '1'),
(383, 83, '_edit_lock', '1623507212:1'),
(384, 25, '_wp_trash_meta_status', 'draft'),
(385, 25, '_wp_trash_meta_time', '1623507329'),
(386, 25, '_wp_desired_post_slug', ''),
(387, 5, '_wp_trash_meta_status', 'pending'),
(388, 5, '_wp_trash_meta_time', '1623507336'),
(389, 1, '_wp_trash_meta_status', 'publish'),
(390, 1, '_wp_trash_meta_time', '1623507341'),
(391, 1, '_wp_desired_post_slug', 'hello-world'),
(392, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:\"1\";}'),
(393, 85, '_edit_lock', '1623560750:1'),
(394, 85, '_wp_trash_meta_status', 'draft'),
(395, 85, '_wp_trash_meta_time', '1623561527'),
(396, 85, '_wp_desired_post_slug', ''),
(397, 87, '_edit_lock', '1623574762:1'),
(398, 89, '_menu_item_type', 'taxonomy'),
(399, 89, '_menu_item_menu_item_parent', '0'),
(400, 89, '_menu_item_object_id', '6'),
(401, 89, '_menu_item_object', 'category'),
(402, 89, '_menu_item_target', ''),
(403, 89, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(404, 89, '_menu_item_xfn', ''),
(405, 89, '_menu_item_url', ''),
(406, 89, '_menu_item_orphaned', '1623562048'),
(407, 90, '_menu_item_type', 'taxonomy'),
(408, 90, '_menu_item_menu_item_parent', '0'),
(409, 90, '_menu_item_object_id', '12'),
(410, 90, '_menu_item_object', 'category'),
(411, 90, '_menu_item_target', ''),
(412, 90, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(413, 90, '_menu_item_xfn', ''),
(414, 90, '_menu_item_url', ''),
(415, 90, '_menu_item_orphaned', '1623562057'),
(416, 91, '_menu_item_type', 'taxonomy'),
(417, 91, '_menu_item_menu_item_parent', '0'),
(418, 91, '_menu_item_object_id', '3'),
(419, 91, '_menu_item_object', 'category'),
(420, 91, '_menu_item_target', ''),
(421, 91, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(422, 91, '_menu_item_xfn', ''),
(423, 91, '_menu_item_url', ''),
(424, 91, '_menu_item_orphaned', '1623562063'),
(425, 92, '_menu_item_type', 'taxonomy'),
(426, 92, '_menu_item_menu_item_parent', '0'),
(427, 92, '_menu_item_object_id', '11'),
(428, 92, '_menu_item_object', 'category'),
(429, 92, '_menu_item_target', ''),
(430, 92, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(431, 92, '_menu_item_xfn', ''),
(432, 92, '_menu_item_url', ''),
(433, 92, '_menu_item_orphaned', '1623562067'),
(434, 93, '_menu_item_type', 'taxonomy'),
(435, 93, '_menu_item_menu_item_parent', '0'),
(436, 93, '_menu_item_object_id', '10'),
(437, 93, '_menu_item_object', 'category'),
(438, 93, '_menu_item_target', ''),
(439, 93, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(440, 93, '_menu_item_xfn', ''),
(441, 93, '_menu_item_url', ''),
(442, 93, '_menu_item_orphaned', '1623562079'),
(443, 94, '_menu_item_type', 'taxonomy'),
(444, 94, '_menu_item_menu_item_parent', '0'),
(445, 94, '_menu_item_object_id', '2'),
(446, 94, '_menu_item_object', 'category'),
(447, 94, '_menu_item_target', ''),
(448, 94, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(449, 94, '_menu_item_xfn', ''),
(450, 94, '_menu_item_url', ''),
(451, 94, '_menu_item_orphaned', '1623562093'),
(452, 95, '_menu_item_type', 'taxonomy'),
(453, 95, '_menu_item_menu_item_parent', '0'),
(454, 95, '_menu_item_object_id', '13'),
(455, 95, '_menu_item_object', 'category'),
(456, 95, '_menu_item_target', ''),
(457, 95, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(458, 95, '_menu_item_xfn', ''),
(459, 95, '_menu_item_url', ''),
(460, 95, '_menu_item_orphaned', '1623562103'),
(461, 96, '_menu_item_type', 'taxonomy'),
(462, 96, '_menu_item_menu_item_parent', '0'),
(463, 96, '_menu_item_object_id', '6'),
(464, 96, '_menu_item_object', 'category'),
(465, 97, '_menu_item_type', 'taxonomy'),
(466, 96, '_menu_item_target', ''),
(467, 97, '_menu_item_menu_item_parent', '0'),
(468, 96, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(469, 97, '_menu_item_object_id', '15'),
(470, 96, '_menu_item_xfn', ''),
(471, 97, '_menu_item_object', 'category'),
(472, 96, '_menu_item_url', ''),
(473, 97, '_menu_item_target', ''),
(474, 96, '_menu_item_orphaned', '1623562107'),
(475, 97, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(476, 97, '_menu_item_xfn', ''),
(477, 97, '_menu_item_url', ''),
(478, 97, '_menu_item_orphaned', '1623562108'),
(479, 98, '_menu_item_type', 'taxonomy'),
(480, 98, '_menu_item_menu_item_parent', '0'),
(481, 99, '_menu_item_type', 'taxonomy'),
(482, 98, '_menu_item_object_id', '12'),
(483, 99, '_menu_item_menu_item_parent', '0'),
(484, 98, '_menu_item_object', 'category'),
(485, 99, '_menu_item_object_id', '16'),
(486, 98, '_menu_item_target', ''),
(487, 99, '_menu_item_object', 'category'),
(488, 98, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(489, 99, '_menu_item_target', ''),
(490, 98, '_menu_item_xfn', ''),
(491, 99, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(492, 98, '_menu_item_url', ''),
(493, 99, '_menu_item_xfn', ''),
(494, 98, '_menu_item_orphaned', '1623562110'),
(495, 99, '_menu_item_url', ''),
(496, 99, '_menu_item_orphaned', '1623562110'),
(497, 100, '_menu_item_type', 'taxonomy'),
(498, 100, '_menu_item_menu_item_parent', '0'),
(499, 100, '_menu_item_object_id', '3'),
(500, 101, '_menu_item_type', 'taxonomy'),
(501, 100, '_menu_item_object', 'category'),
(502, 101, '_menu_item_menu_item_parent', '0'),
(503, 100, '_menu_item_target', ''),
(504, 101, '_menu_item_object_id', '17'),
(505, 100, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(506, 101, '_menu_item_object', 'category'),
(507, 100, '_menu_item_xfn', ''),
(508, 101, '_menu_item_target', ''),
(509, 100, '_menu_item_url', ''),
(510, 101, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(511, 100, '_menu_item_orphaned', '1623562113'),
(512, 101, '_menu_item_xfn', ''),
(513, 101, '_menu_item_url', ''),
(514, 101, '_menu_item_orphaned', '1623562113'),
(515, 102, '_menu_item_type', 'taxonomy'),
(516, 102, '_menu_item_menu_item_parent', '0'),
(517, 102, '_menu_item_object_id', '11'),
(518, 102, '_menu_item_object', 'category'),
(519, 102, '_menu_item_target', ''),
(520, 102, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(521, 102, '_menu_item_xfn', ''),
(522, 102, '_menu_item_url', ''),
(523, 102, '_menu_item_orphaned', '1623562114'),
(524, 103, '_menu_item_type', 'taxonomy'),
(525, 103, '_menu_item_menu_item_parent', '0'),
(526, 103, '_menu_item_object_id', '10'),
(527, 103, '_menu_item_object', 'category'),
(528, 103, '_menu_item_target', ''),
(529, 103, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(530, 103, '_menu_item_xfn', ''),
(531, 103, '_menu_item_url', ''),
(532, 103, '_menu_item_orphaned', '1623562116'),
(533, 104, '_menu_item_type', 'taxonomy'),
(534, 104, '_menu_item_menu_item_parent', '0'),
(535, 104, '_menu_item_object_id', '2'),
(536, 104, '_menu_item_object', 'category'),
(537, 104, '_menu_item_target', ''),
(538, 104, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(539, 104, '_menu_item_xfn', ''),
(540, 104, '_menu_item_url', ''),
(541, 104, '_menu_item_orphaned', '1623562119'),
(542, 105, '_menu_item_type', 'taxonomy'),
(543, 105, '_menu_item_menu_item_parent', '0'),
(544, 105, '_menu_item_object_id', '13'),
(545, 105, '_menu_item_object', 'category'),
(546, 105, '_menu_item_target', ''),
(547, 105, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(548, 105, '_menu_item_xfn', ''),
(549, 105, '_menu_item_url', ''),
(550, 105, '_menu_item_orphaned', '1623562121'),
(551, 106, '_menu_item_type', 'taxonomy'),
(552, 106, '_menu_item_menu_item_parent', '0'),
(553, 106, '_menu_item_object_id', '15'),
(554, 106, '_menu_item_object', 'category'),
(555, 106, '_menu_item_target', ''),
(556, 106, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(557, 106, '_menu_item_xfn', ''),
(558, 106, '_menu_item_url', ''),
(559, 106, '_menu_item_orphaned', '1623562123'),
(560, 107, '_menu_item_type', 'taxonomy'),
(561, 107, '_menu_item_menu_item_parent', '0'),
(562, 107, '_menu_item_object_id', '16'),
(563, 107, '_menu_item_object', 'category'),
(564, 107, '_menu_item_target', ''),
(565, 107, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(566, 107, '_menu_item_xfn', ''),
(567, 107, '_menu_item_url', ''),
(568, 107, '_menu_item_orphaned', '1623562124'),
(569, 108, '_menu_item_type', 'taxonomy'),
(570, 108, '_menu_item_menu_item_parent', '0'),
(571, 108, '_menu_item_object_id', '17'),
(572, 108, '_menu_item_object', 'category'),
(573, 108, '_menu_item_target', ''),
(574, 108, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(575, 108, '_menu_item_xfn', ''),
(576, 108, '_menu_item_url', ''),
(577, 108, '_menu_item_orphaned', '1623562125'),
(668, 119, '_edit_lock', '1623562684:1'),
(669, 83, '_customize_restore_dismissed', '1'),
(680, 120, '_wp_trash_meta_status', 'publish'),
(681, 120, '_wp_trash_meta_time', '1623563612'),
(682, 122, '_edit_lock', '1623570515:1'),
(683, 63, '_edit_lock', '1623565494:1'),
(684, 124, '_edit_lock', '1623565476:1'),
(685, 125, '_edit_lock', '1623565707:1'),
(686, 122, '_edit_last', '1'),
(687, 122, '_wp_page_template', 'templates/template-cover.php'),
(691, 127, '_edit_lock', '1623567848:1'),
(692, 128, '_edit_lock', '1623570534:1'),
(694, 128, '_oembed_24aa410967983e40cbaef1f8d1bbfdb5', '<iframe title=\"ABP Ananda LIVE : মুকুলের তৃণমূলে যোগদান নিয়ে বাগযুদ্ধ দুই শিবিরের, নিউটাউন শ্যুটআউট কাণ্ডে নয়া তথ্য\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/TpkRThMDClU?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(695, 128, '_oembed_time_24aa410967983e40cbaef1f8d1bbfdb5', '1623568352'),
(700, 122, '_wp_old_slug', 'bangali-news__trashed'),
(701, 130, '_edit_lock', '1623570560:1'),
(704, 132, '_edit_lock', '1623570648:1'),
(705, 132, '_oembed_fba81199eff33092c5b6902e96b99800', '<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(706, 132, '_oembed_time_fba81199eff33092c5b6902e96b99800', '1623569226'),
(707, 132, '_oembed_a8e6785ba78452eed456fa74e9b12e5d', '<iframe title=\"ABP Asmita LIVE: Gujarati News LIVE | ABP Gujarati News | અસ્મિતા લાઈવ ટીવી\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/Z-KyhfqjYrE?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(708, 132, '_oembed_time_a8e6785ba78452eed456fa74e9b12e5d', '1623569466'),
(712, 134, '_edit_lock', '1623570769:1'),
(713, 134, '_oembed_e0181b91b240e3ef0a4c3bada44aeca0', '<iframe title=\"COVID-19 Crisis | Monsoon 2021 | Vaccination Campaign | Live Gujarati News |  | TV9 Gujarati LIVE\" width=\"580\" height=\"435\" src=\"https://www.youtube.com/embed/Mvz3_9O4p4s?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(714, 134, '_oembed_time_e0181b91b240e3ef0a4c3bada44aeca0', '1623569955'),
(716, 134, '_wp_page_template', ''),
(717, 136, '_edit_lock', '1623573346:1'),
(721, 136, '_wp_page_template', 'templates/template-cover.php'),
(725, 130, '_wp_page_template', 'templates/template-cover.php'),
(728, 138, '_edit_lock', '1623571251:1'),
(730, 138, '_oembed_113fd61704920409a0ffa99f6d65b844', '<iframe title=\"Hindi News Live: देश-दुनिया की इस वक्त की 100 बड़ी खबरें I Nonstop 100 I Top 100 I June 13, 2021\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/6giviFF-Hck?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(731, 138, '_oembed_time_113fd61704920409a0ffa99f6d65b844', '1623571180'),
(732, 140, '_edit_lock', '1623571513:1'),
(734, 140, '_wp_page_template', 'templates/template-cover.php'),
(735, 143, '_edit_lock', '1623577835:1'),
(737, 145, '_edit_lock', '1623572800:1'),
(738, 145, '_oembed_5f4cacf19e06c04d5775d8d221f2411c', '<iframe title=\"TV9 Marathi Live | Maharashtra Lockdown | Monsoon Update | Mumbai Rain | Malad Building Collapsed\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/-Ku6BOxFIkc?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(739, 145, '_oembed_time_5f4cacf19e06c04d5775d8d221f2411c', '1623571908'),
(742, 143, '_oembed_669c0f19220aa558cf3b0084c84466a6', '<iframe title=\"ABP Majha LIVE | Maharashtra Monsoon | Mumbai Rains | Maharashtra Unlock | Vaccination |Live TV 24X7\" width=\"580\" height=\"326\" src=\"https://www.youtube.com/embed/I6zGBF72o7M?feature=oembed\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>'),
(743, 143, '_oembed_time_669c0f19220aa558cf3b0084c84466a6', '1623577595'),
(746, 87, '_wp_page_template', 'templates/template-full-width.php'),
(785, 153, '_menu_item_type', 'taxonomy'),
(786, 153, '_menu_item_menu_item_parent', '0'),
(787, 153, '_menu_item_object_id', '11'),
(788, 153, '_menu_item_object', 'category'),
(789, 153, '_menu_item_target', ''),
(790, 153, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(791, 153, '_menu_item_xfn', ''),
(792, 153, '_menu_item_url', ''),
(793, 153, '_menu_item_orphaned', '1623572397'),
(839, 145, '_edit_last', '1'),
(840, 145, '_wp_page_template', 'default'),
(843, 159, '_menu_item_type', 'taxonomy'),
(844, 159, '_menu_item_menu_item_parent', '0'),
(845, 159, '_menu_item_object_id', '6'),
(846, 159, '_menu_item_object', 'category'),
(847, 159, '_menu_item_target', ''),
(848, 159, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(849, 159, '_menu_item_xfn', ''),
(850, 159, '_menu_item_url', ''),
(852, 160, '_menu_item_type', 'taxonomy'),
(853, 160, '_menu_item_menu_item_parent', '159'),
(854, 160, '_menu_item_object_id', '12'),
(855, 160, '_menu_item_object', 'category'),
(856, 160, '_menu_item_target', ''),
(857, 160, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(858, 160, '_menu_item_xfn', ''),
(859, 160, '_menu_item_url', ''),
(861, 161, '_menu_item_type', 'taxonomy'),
(862, 161, '_menu_item_menu_item_parent', '0'),
(863, 161, '_menu_item_object_id', '3'),
(864, 161, '_menu_item_object', 'category'),
(865, 161, '_menu_item_target', ''),
(866, 161, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(867, 161, '_menu_item_xfn', ''),
(868, 161, '_menu_item_url', ''),
(870, 162, '_menu_item_type', 'taxonomy'),
(871, 162, '_menu_item_menu_item_parent', '161'),
(872, 162, '_menu_item_object_id', '11'),
(873, 162, '_menu_item_object', 'category'),
(874, 162, '_menu_item_target', ''),
(875, 162, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(876, 162, '_menu_item_xfn', ''),
(877, 162, '_menu_item_url', ''),
(879, 163, '_menu_item_type', 'taxonomy'),
(880, 163, '_menu_item_menu_item_parent', '161'),
(881, 163, '_menu_item_object_id', '10'),
(882, 163, '_menu_item_object', 'category'),
(883, 163, '_menu_item_target', ''),
(884, 163, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(885, 163, '_menu_item_xfn', ''),
(886, 163, '_menu_item_url', ''),
(888, 164, '_menu_item_type', 'taxonomy'),
(889, 164, '_menu_item_menu_item_parent', '0'),
(890, 164, '_menu_item_object_id', '2'),
(891, 164, '_menu_item_object', 'category'),
(892, 164, '_menu_item_target', ''),
(893, 164, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(894, 164, '_menu_item_xfn', ''),
(895, 164, '_menu_item_url', ''),
(897, 165, '_menu_item_type', 'taxonomy'),
(898, 165, '_menu_item_menu_item_parent', '164'),
(899, 165, '_menu_item_object_id', '13'),
(900, 165, '_menu_item_object', 'category'),
(901, 165, '_menu_item_target', ''),
(902, 165, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(903, 165, '_menu_item_xfn', ''),
(904, 165, '_menu_item_url', ''),
(906, 166, '_menu_item_type', 'taxonomy'),
(907, 166, '_menu_item_menu_item_parent', '0'),
(908, 166, '_menu_item_object_id', '15'),
(909, 166, '_menu_item_object', 'category'),
(910, 166, '_menu_item_target', ''),
(911, 166, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(912, 166, '_menu_item_xfn', ''),
(913, 166, '_menu_item_url', ''),
(915, 167, '_menu_item_type', 'taxonomy'),
(916, 167, '_menu_item_menu_item_parent', '166'),
(917, 167, '_menu_item_object_id', '16'),
(918, 167, '_menu_item_object', 'category'),
(919, 167, '_menu_item_target', ''),
(920, 167, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(921, 167, '_menu_item_xfn', ''),
(922, 167, '_menu_item_url', ''),
(924, 168, '_menu_item_type', 'taxonomy'),
(925, 168, '_menu_item_menu_item_parent', '166'),
(926, 168, '_menu_item_object_id', '17'),
(927, 168, '_menu_item_object', 'category'),
(928, 168, '_menu_item_target', ''),
(929, 168, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(930, 168, '_menu_item_xfn', ''),
(931, 168, '_menu_item_url', ''),
(938, 171, '_edit_lock', '1623573968:1'),
(939, 172, '_edit_lock', '1623574359:1');

-- --------------------------------------------------------

--
-- Table structure for table `ap_posts`
--

CREATE TABLE `ap_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_posts`
--

INSERT INTO `ap_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2021-06-11 12:51:00', '2021-06-11 12:51:00', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'open', '', 'hello-world__trashed', '', '', '2021-06-12 14:15:42', '2021-06-12 14:15:42', '', 0, 'http://localhost/wp/?p=1', 0, 'post', '', 1),
(2, 1, '2021-06-11 12:51:00', '2021-06-11 12:51:00', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://localhost/wp/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2021-06-11 12:51:00', '2021-06-11 12:51:00', '', 0, 'http://localhost/wp/?page_id=2', 0, 'page', '', 0),
(3, 1, '2021-06-11 12:51:00', '2021-06-11 12:51:00', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Our website address is: http://localhost/wp.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class=\"privacy-policy-tutorial\">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2021-06-11 12:51:00', '2021-06-11 12:51:00', '', 0, 'http://localhost/wp/?page_id=3', 0, 'page', '', 0),
(4, 1, '2021-06-11 12:51:27', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-11 12:51:27', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=4', 0, 'post', '', 0),
(5, 1, '2021-06-12 13:20:17', '2021-06-12 13:20:17', '<!-- wp:paragraph {\"align\":\"center\",\"backgroundColor\":\"background\",\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-background-background-color has-text-color has-background has-large-font-size\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group {\"align\":\"wide\",\"style\":{\"color\":{\"background\":\"#ffffff\"}}} -->\n<div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"textAlign\":\"center\"} -->\n<h2 class=\"has-text-align-center\"></h2>\n<!-- /wp:heading --></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->', 'Welcome To Ganesha', '', 'trash', 'open', 'open', '', '__trashed', '', '', '2021-06-12 14:15:36', '2021-06-12 14:15:36', '', 0, 'http://localhost/wp/?p=5', 0, 'post', '', 0),
(6, 1, '2021-06-12 11:01:16', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 11:01:16', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=6', 0, 'post', '', 0),
(7, 1, '2021-06-12 11:48:57', '2021-06-12 11:48:57', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2021-06-12 11:48:57', '2021-06-12 11:48:57', '', 5, 'http://localhost/wp/wp-content/uploads/2021/06/logo.png', 0, 'attachment', 'image/png', 0),
(9, 1, '2021-06-12 11:50:03', '2021-06-12 11:50:03', '<!-- wp:paragraph {\"align\":\"center\",\"style\":{\"color\":{\"background\":\"#8da0a7\"}},\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-text-color has-background has-large-font-size\" style=\"background-color:#8da0a7\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-06-12 11:50:03', '2021-06-12 11:50:03', '', 5, 'http://localhost/wp/?p=9', 0, 'revision', '', 0),
(10, 1, '2021-06-12 11:51:43', '2021-06-12 11:51:43', '', 'image', '', 'inherit', 'open', 'closed', '', 'image', '', '', '2021-06-12 11:51:43', '2021-06-12 11:51:43', '', 5, 'http://localhost/wp/wp-content/uploads/2021/06/image.png', 0, 'attachment', 'image/png', 0),
(11, 1, '2021-06-12 11:51:51', '2021-06-12 11:51:51', '<!-- wp:image {\"id\":10,\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"http://localhost/wp/wp-content/uploads/2021/06/image.png\" alt=\"\" class=\"wp-image-10\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph {\"align\":\"center\",\"style\":{\"color\":{\"background\":\"#8da0a7\"}},\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-text-color has-background has-large-font-size\" style=\"background-color:#8da0a7\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-06-12 11:51:51', '2021-06-12 11:51:51', '', 5, 'http://localhost/wp/?p=11', 0, 'revision', '', 0),
(13, 1, '2021-06-12 11:54:51', '2021-06-12 11:54:51', '<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"blob:http://localhost/64199750-f239-44f8-b450-17493ec862c0\" alt=\"\"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:paragraph {\"align\":\"center\",\"style\":{\"color\":{\"background\":\"#8da0a7\"}},\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-text-color has-background has-large-font-size\" style=\"background-color:#8da0a7\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-06-12 11:54:51', '2021-06-12 11:54:51', '', 5, 'http://localhost/wp/?p=13', 0, 'revision', '', 0),
(14, 1, '2021-06-12 11:56:37', '2021-06-12 11:56:37', '<!-- wp:image {\"sizeSlug\":\"large\",\"linkDestination\":\"none\"} -->\n<figure class=\"wp-block-image size-large\"><img src=\"blob:http://localhost/64199750-f239-44f8-b450-17493ec862c0\" alt=\"\"/></figure>\n<!-- /wp:image -->', 'Untitled Reusable Block', '', 'publish', 'closed', 'closed', '', 'untitled-reusable-block', '', '', '2021-06-12 11:56:37', '2021-06-12 11:56:37', '', 0, 'http://localhost/wp/2021/06/12/untitled-reusable-block/', 0, 'wp_block', '', 0),
(16, 1, '2021-06-12 12:00:08', '2021-06-12 12:00:08', '<!-- wp:paragraph {\"align\":\"center\",\"style\":{\"color\":{\"background\":\"#8da0a7\"}},\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-text-color has-background has-large-font-size\" style=\"background-color:#8da0a7\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-06-12 12:00:08', '2021-06-12 12:00:08', '', 5, 'http://localhost/wp/?p=16', 0, 'revision', '', 0),
(17, 1, '2021-06-12 12:25:33', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-12 12:25:33', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=17', 0, 'post', '', 0),
(19, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '', 'The New UMoMA Opens its Doors', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2021-06-12 12:29:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/wp-content/uploads/2021/06/2020-landscape-1.png', 0, 'attachment', 'image/png', 0),
(20, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '<!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">The premier destination for modern art in Northern Sweden. Open from 10 AM to 6 PM every day during the summer months.</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:columns {\"align\":\"wide\"} --><div class=\"wp-block-columns alignwide\"><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-1.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Works and Days</h3><!-- /wp:heading --><!-- wp:paragraph --><p>August 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-3.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Theatre of Operations</h3><!-- /wp:heading --><!-- wp:paragraph --><p>October 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>The Life I Deserve</h3><!-- /wp:heading --><!-- wp:paragraph --><p>August 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-4.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>From Signac to Matisse</h3><!-- /wp:heading --><!-- wp:paragraph --><p>October 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-landscape-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\",\"textColor\":\"accent\"} --><h2 class=\"has-accent-color has-text-align-center\">&#8220;Cyborgs, as the philosopher Donna Haraway established, are not reverent. They do not remember the cosmos.&#8221;</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:paragraph {\"dropCap\":true} --><p class=\"has-drop-cap\">With seven floors of striking architecture, UMoMA shows exhibitions of international contemporary art, sometimes along with art historical retrospectives. Existential, political and philosophical issues are intrinsic to our programme. As visitor you are invited to guided tours artist talks, lectures, film screenings and other events with free admission</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>The exhibitions are produced by UMoMA in collaboration with artists and museums around the world and they often attract international attention. UMoMA has received a Special Commendation from the European Museum of the Year, and was among the top candidates for the Swedish Museum of the Year Award as well as for the Council of Europe Museum Prize.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:group {\"customBackgroundColor\":\"#ffffff\",\"align\":\"wide\"} --><div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">Become a Member and Get Exclusive Offers!</h2><!-- /wp:heading --><!-- wp:paragraph {\"align\":\"center\"} --><p class=\"has-text-align-center\">Members get access to exclusive exhibits and sales. Our memberships cost $99.99 and are billed annually.</p><!-- /wp:paragraph --><!-- wp:button {\"align\":\"center\"} --><div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Join the Club</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div></div><!-- /wp:group --><!-- wp:gallery {\"ids\":[39,38],\"align\":\"wide\"} --><figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" alt=\"\" data-id=\"39\" data-full-url=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" data-link=\"assets/images/2020-square-2/\" class=\"wp-image-39\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" alt=\"\" data-id=\"38\" data-full-url=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" data-link=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1/\" class=\"wp-image-38\"/></figure></li></ul></figure><!-- /wp:gallery -->', 'The New UMoMA Opens its Doors', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 12:29:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=20', 0, 'page', '', 0),
(21, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.</p>\n<!-- /wp:paragraph -->', 'About', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 12:29:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=21', 0, 'page', '', 0),
(22, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.</p>\n<!-- /wp:paragraph -->', 'Contact', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 12:29:50', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=22', 0, 'page', '', 0),
(23, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '', 'Blog', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 12:29:51', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=23', 0, 'page', '', 0),
(24, 1, '2021-06-12 12:29:51', '0000-00-00 00:00:00', '{\n    \"widget_text[2]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjE1OiJBYm91dCBUaGlzIFNpdGUiO3M6NDoidGV4dCI7czo4NToiVGhpcyBtYXkgYmUgYSBnb29kIHBsYWNlIHRvIGludHJvZHVjZSB5b3Vyc2VsZiBhbmQgeW91ciBzaXRlIG9yIGluY2x1ZGUgc29tZSBjcmVkaXRzLiI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",\n            \"title\": \"About This Site\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"724997977f81de2896926f477cb8414a\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"sidebars_widgets[sidebar-1]\": {\n        \"starter_content\": true,\n        \"value\": [\n            \"text-2\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"widget_text[3]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjc6IkZpbmQgVXMiO3M6NDoidGV4dCI7czoxNjg6IjxzdHJvbmc+QWRkcmVzczwvc3Ryb25nPgoxMjMgTWFpbiBTdHJlZXQKTmV3IFlvcmssIE5ZIDEwMDAxCgo8c3Ryb25nPkhvdXJzPC9zdHJvbmc+Ck1vbmRheSZuZGFzaDtGcmlkYXk6IDk6MDBBTSZuZGFzaDs1OjAwUE0KU2F0dXJkYXkgJmFtcDsgU3VuZGF5OiAxMTowMEFNJm5kYXNoOzM6MDBQTSI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",\n            \"title\": \"Find Us\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"31afd8082e685c6bdbb9a9838bbb82a4\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"sidebars_widgets[sidebar-2]\": {\n        \"starter_content\": true,\n        \"value\": [\n            \"text-3\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menus_created_posts\": {\n        \"starter_content\": true,\n        \"value\": [\n            19,\n            20,\n            21,\n            22,\n            23\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu[-1]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Primary\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-1]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/wp/\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -1,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-2]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 21,\n            \"position\": 1,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"About\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-3]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 23,\n            \"position\": 2,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"Blog\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-4]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 22,\n            \"position\": 3,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"Contact\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"twentytwenty::nav_menu_locations[primary]\": {\n        \"starter_content\": true,\n        \"value\": -1,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu[-5]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Primary\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-5]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/wp/\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -5,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-6]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 21,\n            \"position\": 1,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"About\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-7]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 23,\n            \"position\": 2,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"Blog\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-8]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 22,\n            \"position\": 3,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"Contact\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"twentytwenty::nav_menu_locations[expanded]\": {\n        \"starter_content\": true,\n        \"value\": -5,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu[-9]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Social Links Menu\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-9]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Yelp\",\n            \"url\": \"https://www.yelp.com\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-10]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Facebook\",\n            \"url\": \"https://www.facebook.com/wordpress\",\n            \"position\": 1,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-11]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Twitter\",\n            \"url\": \"https://twitter.com/wordpress\",\n            \"position\": 2,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-12]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Instagram\",\n            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",\n            \"position\": 3,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"nav_menu_item[-13]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Email\",\n            \"url\": \"mailto:wordpress@example.com\",\n            \"position\": 4,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"twentytwenty::nav_menu_locations[social]\": {\n        \"starter_content\": true,\n        \"value\": -9,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"show_on_front\": {\n        \"starter_content\": true,\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"page_on_front\": {\n        \"starter_content\": true,\n        \"value\": 20,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"page_for_posts\": {\n        \"starter_content\": true,\n        \"value\": 23,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    },\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [],\n            \"sidebar-1\": [\n                \"text-2\"\n            ],\n            \"sidebar-2\": [\n                \"text-3\"\n            ]\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 12:29:51\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '1a514e3a-1ebb-4439-928a-b78c7c4b3472', '', '', '2021-06-12 12:29:51', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=24', 0, 'customize_changeset', '', 0),
(25, 1, '2021-06-12 14:15:30', '2021-06-12 14:15:30', '<!-- wp:list -->\n<ul><li>TV9 GUJARATI</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><a href=\"https://youtu.be/Mvz3_9O4p4s\">https://youtu.be/Mvz3_9O4p4s</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>ABP</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/Z-KyhfqjYrE\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/Z-KyhfqjYrE\n</div></figure>\n<!-- /wp:embed -->', 'Gujarati NEWS', '', 'trash', 'open', 'open', '', '__trashed-2', '', '', '2021-06-12 14:15:30', '2021-06-12 14:15:30', '', 0, 'http://localhost/wp/?p=25', 0, 'post', '', 0),
(27, 1, '2021-06-12 12:45:20', '2021-06-12 12:45:20', '<!-- wp:paragraph {\"align\":\"center\",\"backgroundColor\":\"background\",\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-background-background-color has-text-color has-background has-large-font-size\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group {\"align\":\"wide\",\"style\":{\"color\":{\"background\":\"#ffffff\"}}} -->\n<div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"textAlign\":\"center\"} -->\n<h2 class=\"has-text-align-center\"></h2>\n<!-- /wp:heading --></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2021-06-12 12:45:20', '2021-06-12 12:45:20', '', 5, 'http://localhost/wp/?p=27', 0, 'revision', '', 0),
(28, 1, '2021-06-12 12:58:58', '2021-06-12 12:58:58', '<!-- wp:list -->\n<ul><li>TV9 GUJARATI</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p><a href=\"https://youtu.be/Mvz3_9O4p4s\">https://youtu.be/Mvz3_9O4p4s</a></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul><li>ABP</li></ul>\n<!-- /wp:list -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/Z-KyhfqjYrE\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/Z-KyhfqjYrE\n</div></figure>\n<!-- /wp:embed -->', 'Gujarati NEWS', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2021-06-12 12:58:58', '2021-06-12 12:58:58', '', 25, 'http://localhost/wp/?p=28', 0, 'revision', '', 0),
(29, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '', 'The New UMoMA Opens its Doors', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2021-06-12 13:03:29', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/wp-content/uploads/2021/06/2020-landscape-1-1.png', 0, 'attachment', 'image/png', 0),
(30, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '<!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">The premier destination for modern art in Northern Sweden. Open from 10 AM to 6 PM every day during the summer months.</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:columns {\"align\":\"wide\"} --><div class=\"wp-block-columns alignwide\"><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-1.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Works and Days</h3><!-- /wp:heading --><!-- wp:paragraph --><p>August 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-3.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>Theatre of Operations</h3><!-- /wp:heading --><!-- wp:paragraph --><p>October 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --><!-- wp:column --><div class=\"wp-block-column\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>The Life I Deserve</h3><!-- /wp:heading --><!-- wp:paragraph --><p>August 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-three-quarters-4.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:heading {\"level\":3} --><h3>From Signac to Matisse</h3><!-- /wp:heading --><!-- wp:paragraph --><p>October 1 -- December 1</p><!-- /wp:paragraph --><!-- wp:button {\"className\":\"is-style-outline\"} --><div class=\"wp-block-button is-style-outline\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Read More</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div><!-- /wp:column --></div><!-- /wp:columns --><!-- wp:image {\"align\":\"full\",\"id\":37,\"sizeSlug\":\"full\"} --><figure class=\"wp-block-image alignfull size-full\"><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-landscape-2.png\" alt=\"\" class=\"wp-image-37\"/></figure><!-- /wp:image --><!-- wp:group {\"align\":\"wide\"} --><div class=\"wp-block-group alignwide\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\",\"textColor\":\"accent\"} --><h2 class=\"has-accent-color has-text-align-center\">&#8220;Cyborgs, as the philosopher Donna Haraway established, are not reverent. They do not remember the cosmos.&#8221;</h2><!-- /wp:heading --></div></div><!-- /wp:group --><!-- wp:paragraph {\"dropCap\":true} --><p class=\"has-drop-cap\">With seven floors of striking architecture, UMoMA shows exhibitions of international contemporary art, sometimes along with art historical retrospectives. Existential, political and philosophical issues are intrinsic to our programme. As visitor you are invited to guided tours artist talks, lectures, film screenings and other events with free admission</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>The exhibitions are produced by UMoMA in collaboration with artists and museums around the world and they often attract international attention. UMoMA has received a Special Commendation from the European Museum of the Year, and was among the top candidates for the Swedish Museum of the Year Award as well as for the Council of Europe Museum Prize.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:group {\"customBackgroundColor\":\"#ffffff\",\"align\":\"wide\"} --><div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group --><div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"><!-- wp:heading {\"align\":\"center\"} --><h2 class=\"has-text-align-center\">Become a Member and Get Exclusive Offers!</h2><!-- /wp:heading --><!-- wp:paragraph {\"align\":\"center\"} --><p class=\"has-text-align-center\">Members get access to exclusive exhibits and sales. Our memberships cost $99.99 and are billed annually.</p><!-- /wp:paragraph --><!-- wp:button {\"align\":\"center\"} --><div class=\"wp-block-button aligncenter\"><a class=\"wp-block-button__link\" href=\"https://make.wordpress.org/core/2019/09/27/block-editor-theme-related-updates-in-wordpress-5-3/\">Join the Club</a></div><!-- /wp:button --></div></div><!-- /wp:group --></div></div><!-- /wp:group --><!-- wp:gallery {\"ids\":[39,38],\"align\":\"wide\"} --><figure class=\"wp-block-gallery alignwide columns-2 is-cropped\"><ul class=\"blocks-gallery-grid\"><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" alt=\"\" data-id=\"39\" data-full-url=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-2.png\" data-link=\"assets/images/2020-square-2/\" class=\"wp-image-39\"/></figure></li><li class=\"blocks-gallery-item\"><figure><img src=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" alt=\"\" data-id=\"38\" data-full-url=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1.png\" data-link=\"http://localhost/wp/wp-content/themes/twentytwenty/assets/images/2020-square-1/\" class=\"wp-image-38\"/></figure></li></ul></figure><!-- /wp:gallery -->', 'The New UMoMA Opens its Doors', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:03:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=30', 0, 'page', '', 0),
(31, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.</p>\n<!-- /wp:paragraph -->', 'About', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:03:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=31', 0, 'page', '', 0),
(32, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p>This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.</p>\n<!-- /wp:paragraph -->', 'Contact', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:03:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=32', 0, 'page', '', 0),
(33, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '', 'Blog', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:03:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=33', 0, 'page', '', 0);
INSERT INTO `ap_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(34, 1, '2021-06-12 13:03:32', '0000-00-00 00:00:00', '{\n    \"widget_text[4]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjE1OiJBYm91dCBUaGlzIFNpdGUiO3M6NDoidGV4dCI7czo4NToiVGhpcyBtYXkgYmUgYSBnb29kIHBsYWNlIHRvIGludHJvZHVjZSB5b3Vyc2VsZiBhbmQgeW91ciBzaXRlIG9yIGluY2x1ZGUgc29tZSBjcmVkaXRzLiI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",\n            \"title\": \"About This Site\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"724997977f81de2896926f477cb8414a\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"sidebars_widgets[sidebar-1]\": {\n        \"starter_content\": true,\n        \"value\": [\n            \"text-4\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"widget_text[5]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjc6IkZpbmQgVXMiO3M6NDoidGV4dCI7czoxNjg6IjxzdHJvbmc+QWRkcmVzczwvc3Ryb25nPgoxMjMgTWFpbiBTdHJlZXQKTmV3IFlvcmssIE5ZIDEwMDAxCgo8c3Ryb25nPkhvdXJzPC9zdHJvbmc+Ck1vbmRheSZuZGFzaDtGcmlkYXk6IDk6MDBBTSZuZGFzaDs1OjAwUE0KU2F0dXJkYXkgJmFtcDsgU3VuZGF5OiAxMTowMEFNJm5kYXNoOzM6MDBQTSI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",\n            \"title\": \"Find Us\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"31afd8082e685c6bdbb9a9838bbb82a4\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"sidebars_widgets[sidebar-2]\": {\n        \"starter_content\": true,\n        \"value\": [\n            \"text-5\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menus_created_posts\": {\n        \"starter_content\": true,\n        \"value\": [\n            29,\n            30,\n            31,\n            32,\n            33\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu[-1]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Primary\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-1]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/wp/\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -1,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-2]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 31,\n            \"position\": 1,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"About\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-3]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 33,\n            \"position\": 2,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"Blog\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-4]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 32,\n            \"position\": 3,\n            \"nav_menu_term_id\": -1,\n            \"title\": \"Contact\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"twentytwenty::nav_menu_locations[primary]\": {\n        \"starter_content\": true,\n        \"value\": -1,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu[-5]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Primary\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-5]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/wp/\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -5,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-6]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 31,\n            \"position\": 1,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"About\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-7]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 33,\n            \"position\": 2,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"Blog\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-8]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"type\": \"post_type\",\n            \"object\": \"page\",\n            \"object_id\": 32,\n            \"position\": 3,\n            \"nav_menu_term_id\": -5,\n            \"title\": \"Contact\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"twentytwenty::nav_menu_locations[expanded]\": {\n        \"starter_content\": true,\n        \"value\": -5,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu[-9]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"name\": \"Social Links Menu\"\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-9]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Yelp\",\n            \"url\": \"https://www.yelp.com\",\n            \"position\": 0,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-10]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Facebook\",\n            \"url\": \"https://www.facebook.com/wordpress\",\n            \"position\": 1,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-11]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Twitter\",\n            \"url\": \"https://twitter.com/wordpress\",\n            \"position\": 2,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-12]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Instagram\",\n            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",\n            \"position\": 3,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"nav_menu_item[-13]\": {\n        \"starter_content\": true,\n        \"value\": {\n            \"title\": \"Email\",\n            \"url\": \"mailto:wordpress@example.com\",\n            \"position\": 4,\n            \"nav_menu_term_id\": -9,\n            \"object_id\": 0\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"twentytwenty::nav_menu_locations[social]\": {\n        \"starter_content\": true,\n        \"value\": -9,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"show_on_front\": {\n        \"starter_content\": true,\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"page_on_front\": {\n        \"starter_content\": true,\n        \"value\": 30,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    },\n    \"page_for_posts\": {\n        \"starter_content\": true,\n        \"value\": 33,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:03:32\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '740ba3d7-8ea5-425c-ab79-0f856e872d83', '', '', '2021-06-12 13:03:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=34', 0, 'customize_changeset', '', 0),
(37, 1, '2021-06-12 13:22:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2021-06-12 13:22:31', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:31', '0000-00-00 00:00:00', '', 6, 'http://localhost/wp/?p=38', 1, 'nav_menu_item', '', 0),
(39, 1, '2021-06-12 13:22:32', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:32', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2021-06-12 13:22:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:33', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=40', 1, 'nav_menu_item', '', 0),
(41, 1, '2021-06-12 13:22:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:35', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2021-06-12 13:22:36', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:36', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=42', 1, 'nav_menu_item', '', 0),
(43, 1, '2021-06-12 13:22:37', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:37', '0000-00-00 00:00:00', '', 2, 'http://localhost/wp/?p=43', 1, 'nav_menu_item', '', 0),
(44, 1, '2021-06-12 13:22:38', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=44', 1, 'nav_menu_item', '', 0),
(45, 1, '2021-06-12 13:22:39', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:39', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=45', 1, 'nav_menu_item', '', 0),
(46, 1, '2021-06-12 13:22:40', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:40', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=46', 1, 'nav_menu_item', '', 0),
(47, 1, '2021-06-12 13:22:41', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=47', 1, 'nav_menu_item', '', 0),
(48, 1, '2021-06-12 13:22:42', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-12 13:22:42', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=48', 1, 'nav_menu_item', '', 0),
(60, 1, '2021-06-12 13:35:49', '2021-06-12 13:35:49', '\n					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->\n					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">Create your website with blocks</h2>\n					<!-- /wp:heading -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->\n					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->\n					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"&#8220;Roses Trémières&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->\n					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"&#8220;In the Bois de Boulogne&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"center\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->\n					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"&#8220;Young Woman in Mauve&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer {\"height\":50} -->\n					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->\n					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Add block patterns</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Block patterns are pre-designed groups of blocks. To add one, select the Add Block button [+] in the toolbar at the top of the editor. Switch to the Patterns tab underneath the search bar, and choose a pattern.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Frame your images</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Twenty Twenty-One includes stylish borders for your content. With an Image block selected, open the &quot;Styles&quot; panel within the Editor sidebar. Select the &quot;Frame&quot; block style to activate it.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Overlap columns</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Twenty Twenty-One also includes an overlap style for column blocks. With a Columns block selected, open the &quot;Styles&quot; panel within the Editor sidebar. Choose the &quot;Overlap&quot; block style to try it out.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->\n					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->\n					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->\n					<p class=\"has-huge-font-size\">Need help?</p>\n					<!-- /wp:paragraph -->\n\n					<!-- wp:spacer {\"height\":75} -->\n					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns -->\n					<div class=\"wp-block-columns\"><!-- wp:column -->\n					<div class=\"wp-block-column\"><!-- wp:paragraph -->\n					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">Read the Theme Documentation</a></p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column -->\n					<div class=\"wp-block-column\"><!-- wp:paragraph -->\n					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">Check out the Support Forums</a></p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer {\"height\":20} -->\n					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer --></div></div>\n					<!-- /wp:cover -->', 'Create your website with blocks', '', 'publish', 'closed', 'closed', '', 'create-your-website-with-blocks', '', '', '2021-06-12 13:35:49', '2021-06-12 13:35:49', '', 0, 'http://localhost/wp/?page_id=60', 0, 'page', '', 0),
(61, 1, '2021-06-12 13:35:51', '2021-06-12 13:35:51', '<!-- wp:paragraph -->\n<p>You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.</p>\n<!-- /wp:paragraph -->', 'About', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2021-06-12 13:35:51', '2021-06-12 13:35:51', '', 0, 'http://localhost/wp/?page_id=61', 0, 'page', '', 0),
(62, 1, '2021-06-12 13:35:52', '2021-06-12 13:35:52', '<!-- wp:paragraph -->\n<p>This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.</p>\n<!-- /wp:paragraph -->', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2021-06-12 13:35:52', '2021-06-12 13:35:52', '', 0, 'http://localhost/wp/?page_id=62', 0, 'page', '', 0),
(63, 1, '2021-06-12 13:35:54', '2021-06-12 13:35:54', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2021-06-12 13:35:54', '2021-06-12 13:35:54', '', 0, 'http://localhost/wp/?page_id=63', 0, 'page', '', 0),
(64, 1, '2021-06-12 13:35:49', '2021-06-12 13:35:49', '{\n    \"nav_menus_created_posts\": {\n        \"starter_content\": true,\n        \"value\": [\n            60,\n            61,\n            62,\n            63\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"nav_menu[-1]\": {\n        \"value\": {\n            \"name\": \"Primary menu\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-1]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 0,\n            \"type\": \"custom\",\n            \"title\": \"Home\",\n            \"url\": \"http://localhost/wp/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"nav_menu_term_id\": -1,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-2]\": {\n        \"value\": {\n            \"object_id\": 61,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"post_type\",\n            \"title\": \"About\",\n            \"url\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"About\",\n            \"nav_menu_term_id\": -1,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-3]\": {\n        \"value\": {\n            \"object_id\": 63,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"post_type\",\n            \"title\": \"Blog\",\n            \"url\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Blog\",\n            \"nav_menu_term_id\": -1,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-4]\": {\n        \"value\": {\n            \"object_id\": 62,\n            \"object\": \"page\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"post_type\",\n            \"title\": \"Contact\",\n            \"url\": \"\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"Contact\",\n            \"nav_menu_term_id\": -1,\n            \"_invalid\": false,\n            \"type_label\": \"Page\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"twentytwentyone::nav_menu_locations[primary]\": {\n        \"starter_content\": true,\n        \"value\": -1,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"nav_menu[-5]\": {\n        \"value\": {\n            \"name\": \"Secondary menu\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": false\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-5]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 0,\n            \"type\": \"custom\",\n            \"title\": \"Facebook\",\n            \"url\": \"https://www.facebook.com/wordpress\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"nav_menu_term_id\": -5,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-6]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 1,\n            \"type\": \"custom\",\n            \"title\": \"Twitter\",\n            \"url\": \"https://twitter.com/wordpress\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"nav_menu_term_id\": -5,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-7]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 2,\n            \"type\": \"custom\",\n            \"title\": \"Instagram\",\n            \"url\": \"https://www.instagram.com/explore/tags/wordcamp/\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"nav_menu_term_id\": -5,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"nav_menu_item[-8]\": {\n        \"value\": {\n            \"object_id\": 0,\n            \"object\": \"\",\n            \"menu_item_parent\": 0,\n            \"position\": 3,\n            \"type\": \"custom\",\n            \"title\": \"Email\",\n            \"url\": \"mailto:wordpress@example.com\",\n            \"target\": \"\",\n            \"attr_title\": \"\",\n            \"description\": \"\",\n            \"classes\": \"\",\n            \"xfn\": \"\",\n            \"status\": \"publish\",\n            \"original_title\": \"\",\n            \"nav_menu_term_id\": -5,\n            \"_invalid\": false,\n            \"type_label\": \"Custom Link\"\n        },\n        \"type\": \"nav_menu_item\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"twentytwentyone::nav_menu_locations[footer]\": {\n        \"starter_content\": true,\n        \"value\": -5,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"show_on_front\": {\n        \"starter_content\": true,\n        \"value\": \"page\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"page_on_front\": {\n        \"starter_content\": true,\n        \"value\": 60,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"page_for_posts\": {\n        \"starter_content\": true,\n        \"value\": 63,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:34:05\"\n    },\n    \"blogdescription\": {\n        \"value\": \"\",\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"site_icon\": {\n        \"value\": 65,\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    },\n    \"twentytwentyone::display_title_and_tagline\": {\n        \"value\": false,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 13:35:49\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', 'e2e02643-f672-4874-a8f8-f65be05d4dee', '', '', '2021-06-12 13:35:49', '2021-06-12 13:35:49', '', 0, 'http://localhost/wp/?p=64', 0, 'customize_changeset', '', 0),
(65, 1, '2021-06-12 13:35:24', '2021-06-12 13:35:24', 'http://localhost/wp/wp-content/uploads/2021/06/cropped-logo.png', 'cropped-logo.png', '', 'inherit', 'open', 'closed', '', 'cropped-logo-png', '', '', '2021-06-12 13:35:24', '2021-06-12 13:35:24', '', 0, 'http://localhost/wp/wp-content/uploads/2021/06/cropped-logo.png', 0, 'attachment', 'image/png', 0),
(67, 1, '2021-06-12 13:35:49', '2021-06-12 13:35:49', '\n					<!-- wp:heading {\"align\":\"wide\",\"fontSize\":\"gigantic\",\"style\":{\"typography\":{\"lineHeight\":\"1.1\"}}} -->\n					<h2 class=\"alignwide has-text-align-wide has-gigantic-font-size\" style=\"line-height:1.1\">Create your website with blocks</h2>\n					<!-- /wp:heading -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns {\"verticalAlignment\":\"center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-columns-overlap\"} -->\n					<div class=\"wp-block-columns alignwide are-vertically-aligned-center is-style-twentytwentyone-columns-overlap\"><!-- wp:column {\"verticalAlignment\":\"center\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\"} -->\n					<figure class=\"wp-block-image alignfull size-large\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/roses-tremieres-hollyhocks-1884.jpg\" alt=\"&#8220;Roses Trémières&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:image {\"align\":\"full\",\"sizeSlug\":\"large\",\"className\":\"is-style-twentytwentyone-image-frame\"} -->\n					<figure class=\"wp-block-image alignfull size-large is-style-twentytwentyone-image-frame\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/in-the-bois-de-boulogne.jpg\" alt=\"&#8220;In the Bois de Boulogne&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"center\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-center\"><!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:image {\"sizeSlug\":\"large\",\"className\":\"alignfull size-full is-style-twentytwentyone-border\"} -->\n					<figure class=\"wp-block-image size-large alignfull size-full is-style-twentytwentyone-border\"><img src=\"http://localhost/wp/wp-content/themes/twentytwentyone/assets/images/young-woman-in-mauve.jpg\" alt=\"&#8220;Young Woman in Mauve&#8221; by Berthe Morisot\"/></figure>\n					<!-- /wp:image --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer {\"height\":50} -->\n					<div style=\"height:50px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns {\"verticalAlignment\":\"top\",\"align\":\"wide\"} -->\n					<div class=\"wp-block-columns alignwide are-vertically-aligned-top\"><!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Add block patterns</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Block patterns are pre-designed groups of blocks. To add one, select the Add Block button [+] in the toolbar at the top of the editor. Switch to the Patterns tab underneath the search bar, and choose a pattern.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Frame your images</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Twenty Twenty-One includes stylish borders for your content. With an Image block selected, open the &quot;Styles&quot; panel within the Editor sidebar. Select the &quot;Frame&quot; block style to activate it.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column {\"verticalAlignment\":\"top\"} -->\n					<div class=\"wp-block-column is-vertically-aligned-top\"><!-- wp:heading {\"level\":3} -->\n					<h3>Overlap columns</h3>\n					<!-- /wp:heading -->\n\n					<!-- wp:paragraph -->\n					<p>Twenty Twenty-One also includes an overlap style for column blocks. With a Columns block selected, open the &quot;Styles&quot; panel within the Editor sidebar. Choose the &quot;Overlap&quot; block style to try it out.</p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer -->\n					<div style=\"height:100px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:cover {\"overlayColor\":\"green\",\"contentPosition\":\"center center\",\"align\":\"wide\",\"className\":\"is-style-twentytwentyone-border\"} -->\n					<div class=\"wp-block-cover alignwide has-green-background-color has-background-dim is-style-twentytwentyone-border\"><div class=\"wp-block-cover__inner-container\"><!-- wp:spacer {\"height\":20} -->\n					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:paragraph {\"fontSize\":\"huge\"} -->\n					<p class=\"has-huge-font-size\">Need help?</p>\n					<!-- /wp:paragraph -->\n\n					<!-- wp:spacer {\"height\":75} -->\n					<div style=\"height:75px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer -->\n\n					<!-- wp:columns -->\n					<div class=\"wp-block-columns\"><!-- wp:column -->\n					<div class=\"wp-block-column\"><!-- wp:paragraph -->\n					<p><a href=\"https://wordpress.org/support/article/twenty-twenty-one/\">Read the Theme Documentation</a></p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column -->\n\n					<!-- wp:column -->\n					<div class=\"wp-block-column\"><!-- wp:paragraph -->\n					<p><a href=\"https://wordpress.org/support/theme/twentytwentyone/\">Check out the Support Forums</a></p>\n					<!-- /wp:paragraph --></div>\n					<!-- /wp:column --></div>\n					<!-- /wp:columns -->\n\n					<!-- wp:spacer {\"height\":20} -->\n					<div style=\"height:20px\" aria-hidden=\"true\" class=\"wp-block-spacer\"></div>\n					<!-- /wp:spacer --></div></div>\n					<!-- /wp:cover -->', 'Create your website with blocks', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2021-06-12 13:35:49', '2021-06-12 13:35:49', '', 60, 'http://localhost/wp/?p=67', 0, 'revision', '', 0),
(69, 1, '2021-06-12 13:35:51', '2021-06-12 13:35:51', '<!-- wp:paragraph -->\n<p>You might be an artist who would like to introduce yourself and your work here or maybe you&rsquo;re a business with a mission to describe.</p>\n<!-- /wp:paragraph -->', 'About', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2021-06-12 13:35:51', '2021-06-12 13:35:51', '', 61, 'http://localhost/wp/?p=69', 0, 'revision', '', 0),
(71, 1, '2021-06-12 13:35:52', '2021-06-12 13:35:52', '<!-- wp:paragraph -->\n<p>This is a page with some basic contact information, such as an address and phone number. You might also try a plugin to add a contact form.</p>\n<!-- /wp:paragraph -->', 'Contact', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2021-06-12 13:35:52', '2021-06-12 13:35:52', '', 62, 'http://localhost/wp/?p=71', 0, 'revision', '', 0),
(73, 1, '2021-06-12 13:35:54', '2021-06-12 13:35:54', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2021-06-12 13:35:54', '2021-06-12 13:35:54', '', 63, 'http://localhost/wp/?p=73', 0, 'revision', '', 0),
(82, 1, '2021-06-12 14:09:55', '2021-06-12 14:09:55', '<!-- wp:paragraph {\"align\":\"center\",\"backgroundColor\":\"background\",\"textColor\":\"black\",\"fontSize\":\"large\"} -->\n<p class=\"has-text-align-center has-black-color has-background-background-color has-text-color has-background has-large-font-size\"><strong><em>Welcome to Ganesha for NEWS.</em></strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:group {\"align\":\"wide\",\"style\":{\"color\":{\"background\":\"#ffffff\"}}} -->\n<div class=\"wp-block-group alignwide has-background\" style=\"background-color:#ffffff\"><div class=\"wp-block-group__inner-container\"><!-- wp:group -->\n<div class=\"wp-block-group\"><div class=\"wp-block-group__inner-container\"></div></div>\n<!-- /wp:group --></div></div>\n<!-- /wp:group -->', 'Welcome To Ganesha', '', 'inherit', 'closed', 'closed', '', '5-autosave-v1', '', '', '2021-06-12 14:09:55', '2021-06-12 14:09:55', '', 5, 'http://localhost/wp/?p=82', 0, 'revision', '', 0),
(83, 1, '2021-06-12 14:13:31', '0000-00-00 00:00:00', '{\n    \"twentytwentyone::nav_menu_locations[primary]\": {\n        \"value\": 19,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 14:13:31\"\n    },\n    \"twentytwentyone::nav_menu_locations[footer]\": {\n        \"value\": 19,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 14:13:31\"\n    },\n    \"nav_menu[19]\": {\n        \"value\": {\n            \"name\": \"MENU\",\n            \"description\": \"\",\n            \"parent\": 0,\n            \"auto_add\": true\n        },\n        \"type\": \"nav_menu\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-12 14:13:31\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '2537131b-e253-4f54-bf8c-01a829f9f5f5', '', '', '2021-06-12 14:13:31', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=83', 0, 'customize_changeset', '', 0),
(84, 1, '2021-06-12 14:15:42', '2021-06-12 14:15:42', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2021-06-12 14:15:42', '2021-06-12 14:15:42', '', 1, 'http://localhost/wp/?p=84', 0, 'revision', '', 0),
(85, 1, '2021-06-13 05:18:47', '2021-06-13 05:18:47', '', '3', '', 'trash', 'open', 'open', '', '__trashed-3', '', '', '2021-06-13 05:18:47', '2021-06-13 05:18:47', '', 0, 'http://localhost/wp/?p=85', 0, 'post', '', 0),
(86, 1, '2021-06-13 05:18:47', '2021-06-13 05:18:47', '', '3', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2021-06-13 05:18:47', '2021-06-13 05:18:47', '', 85, 'http://localhost/wp/?p=86', 0, 'revision', '', 0),
(87, 1, '2021-06-13 07:03:09', '2021-06-13 07:03:09', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><strong><em>Welcome to Ganesha for NEWS</em></strong></p>\n<!-- /wp:paragraph -->', 'Ganesha', '', 'publish', 'open', 'open', '', 'ganesha', '', '', '2021-06-13 08:40:23', '2021-06-13 08:40:23', '', 0, 'http://localhost/wp/?p=87', 0, 'post', '', 0),
(88, 1, '2021-06-13 05:22:06', '2021-06-13 05:22:06', '<!-- wp:paragraph -->\n<p>Welcome to Ganesha for NEWS</p>\n<!-- /wp:paragraph -->', 'Ganesha', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2021-06-13 05:22:06', '2021-06-13 05:22:06', '', 87, 'http://localhost/wp/?p=88', 0, 'revision', '', 0),
(89, 1, '2021-06-13 05:27:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:27:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=89', 1, 'nav_menu_item', '', 0),
(90, 1, '2021-06-13 05:27:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:27:28', '0000-00-00 00:00:00', '', 6, 'http://localhost/wp/?p=90', 1, 'nav_menu_item', '', 0),
(91, 1, '2021-06-13 05:27:38', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:27:38', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=91', 1, 'nav_menu_item', '', 0),
(92, 1, '2021-06-13 05:27:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:27:43', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=92', 1, 'nav_menu_item', '', 0),
(93, 1, '2021-06-13 05:27:47', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:27:47', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=93', 1, 'nav_menu_item', '', 0),
(94, 1, '2021-06-13 05:28:00', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:00', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=94', 1, 'nav_menu_item', '', 0),
(95, 1, '2021-06-13 05:28:14', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:14', '0000-00-00 00:00:00', '', 2, 'http://localhost/wp/?p=95', 1, 'nav_menu_item', '', 0),
(96, 1, '2021-06-13 05:28:20', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:20', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=96', 1, 'nav_menu_item', '', 0),
(97, 1, '2021-06-13 05:28:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=97', 1, 'nav_menu_item', '', 0),
(98, 1, '2021-06-13 05:28:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:28', '0000-00-00 00:00:00', '', 6, 'http://localhost/wp/?p=98', 1, 'nav_menu_item', '', 0),
(99, 1, '2021-06-13 05:28:28', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:28', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=99', 1, 'nav_menu_item', '', 0),
(100, 1, '2021-06-13 05:28:30', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=100', 1, 'nav_menu_item', '', 0),
(101, 1, '2021-06-13 05:28:31', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:31', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=101', 1, 'nav_menu_item', '', 0),
(102, 1, '2021-06-13 05:28:33', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:33', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=102', 1, 'nav_menu_item', '', 0),
(103, 1, '2021-06-13 05:28:34', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:34', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=103', 1, 'nav_menu_item', '', 0),
(104, 1, '2021-06-13 05:28:36', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:36', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=104', 1, 'nav_menu_item', '', 0),
(105, 1, '2021-06-13 05:28:39', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:39', '0000-00-00 00:00:00', '', 2, 'http://localhost/wp/?p=105', 1, 'nav_menu_item', '', 0),
(106, 1, '2021-06-13 05:28:41', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=106', 1, 'nav_menu_item', '', 0),
(107, 1, '2021-06-13 05:28:43', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:43', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=107', 1, 'nav_menu_item', '', 0),
(108, 1, '2021-06-13 05:28:44', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 05:28:44', '0000-00-00 00:00:00', '', 15, 'http://localhost/wp/?p=108', 1, 'nav_menu_item', '', 0),
(119, 1, '2021-06-13 05:37:59', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-13 05:37:59', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=119', 0, 'post', '', 0),
(120, 1, '2021-06-13 05:53:28', '2021-06-13 05:53:28', '{\n    \"old_sidebars_widgets_data\": {\n        \"value\": {\n            \"wp_inactive_widgets\": [\n                \"text-2\",\n                \"text-3\"\n            ],\n            \"sidebar-1\": [\n                \"search-2\",\n                \"recent-posts-2\",\n                \"recent-comments-2\",\n                \"archives-2\",\n                \"categories-2\",\n                \"meta-2\"\n            ],\n            \"home-content\": [],\n            \"home-sidebar\": [],\n            \"footer-1\": [],\n            \"footer-2\": [],\n            \"footer-3\": [],\n            \"footer-4\": [],\n            \"header-ad\": [],\n            \"archive-ad\": []\n        },\n        \"type\": \"global_variable\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-13 05:53:22\"\n    },\n    \"twentytwenty::nav_menu_locations[primary]\": {\n        \"value\": 23,\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2021-06-13 05:53:22\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '082deafe-abe6-4b9e-8cff-1786d706118b', '', '', '2021-06-13 05:53:28', '2021-06-13 05:53:28', '', 0, 'http://localhost/wp/2021/06/13/082deafe-abe6-4b9e-8cff-1786d706118b/', 0, 'customize_changeset', '', 0),
(121, 1, '2021-06-13 05:57:43', '2021-06-13 05:57:43', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><strong><em>Welcome to Ganesha for NEWS</em></strong></p>\n<!-- /wp:paragraph -->', 'Ganesha', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2021-06-13 05:57:43', '2021-06-13 05:57:43', '', 87, 'http://localhost/wp/?p=121', 0, 'revision', '', 0),
(122, 1, '2021-06-13 06:10:58', '2021-06-13 06:10:58', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->\n<p style=\"font-size:34px\"><strong><em>Here you can watch the Bangali News</em></strong></p>\n<!-- /wp:paragraph -->', 'Bangali  NEWS', '', 'publish', 'open', 'open', '', 'bangali-news', '', '', '2021-06-13 07:16:08', '2021-06-13 07:16:08', '', 0, 'http://localhost/wp/?p=122', 0, 'post', '', 0),
(123, 1, '2021-06-13 06:06:04', '2021-06-13 06:06:04', '<!-- wp:paragraph -->\n<p>Here you can watch the Bangali News</p>\n<!-- /wp:paragraph -->', 'Bangali NEWS', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2021-06-13 06:06:04', '2021-06-13 06:06:04', '', 122, 'http://localhost/wp/?p=123', 0, 'revision', '', 0),
(124, 1, '2021-06-13 06:26:08', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2021-06-13 06:26:08', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?page_id=124', 0, 'page', '', 0),
(125, 1, '2021-06-13 06:30:47', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-13 06:30:47', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=125', 0, 'post', '', 0),
(126, 1, '2021-06-13 07:05:37', '2021-06-13 07:05:37', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":34}}} -->\n<p style=\"font-size:34px\"><strong><em>Here you can watch the Bangali News</em></strong></p>\n<!-- /wp:paragraph -->', 'Bangali  NEWS', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2021-06-13 07:05:37', '2021-06-13 07:05:37', '', 122, 'http://localhost/wp/?p=126', 0, 'revision', '', 0),
(127, 1, '2021-06-13 07:06:21', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-13 07:06:21', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=127', 0, 'post', '', 0);
INSERT INTO `ap_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(128, 1, '2021-06-13 07:12:29', '2021-06-13 07:12:29', '<!-- wp:paragraph {\"fontSize\":\"larger\"} -->\n<p class=\"has-larger-font-size\">Here you can watch ABP NEWS in Bangali.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can touch this link than you can see the live ABP NEWS</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://www.youtube.com/watch?v=TpkRThMDClU\\u0026feature=youtu.be\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=TpkRThMDClU&amp;feature=youtu.be\n</div></figure>\n<!-- /wp:embed -->', 'ABP NEWS', '', 'publish', 'open', 'open', '', 'abp-news', '', '', '2021-06-13 07:12:29', '2021-06-13 07:12:29', '', 0, 'http://localhost/wp/?p=128', 0, 'post', '', 0),
(129, 1, '2021-06-13 07:12:29', '2021-06-13 07:12:29', '<!-- wp:paragraph {\"fontSize\":\"larger\"} -->\n<p class=\"has-larger-font-size\">Here you can watch ABP NEWS in Bangali.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You can touch this link than you can see the live ABP NEWS</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://www.youtube.com/watch?v=TpkRThMDClU\\u0026feature=youtu.be\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=TpkRThMDClU&amp;feature=youtu.be\n</div></figure>\n<!-- /wp:embed -->', 'ABP NEWS', '', 'inherit', 'closed', 'closed', '', '128-revision-v1', '', '', '2021-06-13 07:12:29', '2021-06-13 07:12:29', '', 128, 'http://localhost/wp/?p=129', 0, 'revision', '', 0),
(130, 1, '2021-06-13 07:18:21', '2021-06-13 07:18:21', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><strong><em>Here you can watch the Gujrati News</em></strong>.</p>\n<!-- /wp:paragraph -->', 'Gujarati NEWS', '', 'publish', 'open', 'open', '', 'gujarati-news', '', '', '2021-06-13 07:51:39', '2021-06-13 07:51:39', '', 0, 'http://localhost/wp/?p=130', 0, 'post', '', 0),
(131, 1, '2021-06-13 07:18:21', '2021-06-13 07:18:21', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><strong><em>Here you can watch the Gujrati News</em></strong>.</p>\n<!-- /wp:paragraph -->', 'Gujarati NEWS', '', 'inherit', 'closed', 'closed', '', '130-revision-v1', '', '', '2021-06-13 07:18:21', '2021-06-13 07:18:21', '', 130, 'http://localhost/wp/?p=131', 0, 'revision', '', 0),
(132, 1, '2021-06-13 07:31:12', '2021-06-13 07:31:12', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><em>Here You can watch ABP Gujarati NEWS.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Gujrati live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://www.youtube.com/watch?v=Z-KyhfqjYrE\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=Z-KyhfqjYrE\n</div></figure>\n<!-- /wp:embed -->', 'ABP Gujarati NEWS', '', 'publish', 'open', 'open', '', 'abp-gujarati-news', '', '', '2021-06-13 07:34:09', '2021-06-13 07:34:09', '', 0, 'http://localhost/wp/?p=132', 0, 'post', '', 0),
(133, 1, '2021-06-13 07:31:12', '2021-06-13 07:31:12', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><em>Here You can watch ABP Gujarati NEWS.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Gujrati live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://www.youtube.com/watch?v=Z-KyhfqjYrE\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://www.youtube.com/watch?v=Z-KyhfqjYrE\n</div></figure>\n<!-- /wp:embed -->', 'ABP Gujarati NEWS', '', 'inherit', 'closed', 'closed', '', '132-revision-v1', '', '', '2021-06-13 07:31:12', '2021-06-13 07:31:12', '', 132, 'http://localhost/wp/?p=133', 0, 'revision', '', 0),
(134, 1, '2021-06-13 07:40:00', '2021-06-13 07:40:00', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><em><strong>Here You can watch TV9 Gujarati NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the TV9 Gujrati live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/Mvz3_9O4p4s\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-4-3 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-4-3 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/Mvz3_9O4p4s\n</div></figure>\n<!-- /wp:embed -->', 'TV9 Gujarati', '', 'publish', 'open', 'open', '', 'tv9-gujarati', '', '', '2021-06-13 07:52:03', '2021-06-13 07:52:03', '', 0, 'http://localhost/wp/?p=134', 0, 'post', '', 0),
(135, 1, '2021-06-13 07:40:00', '2021-06-13 07:40:00', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><em><strong>Here You can watch TV9 Gujarati NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the TV9 Gujrati live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/Mvz3_9O4p4s\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-4-3 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-4-3 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/Mvz3_9O4p4s\n</div></figure>\n<!-- /wp:embed -->', 'TV9 Gujarati', '', 'inherit', 'closed', 'closed', '', '134-revision-v1', '', '', '2021-06-13 07:40:00', '2021-06-13 07:40:00', '', 134, 'http://localhost/wp/?p=135', 0, 'revision', '', 0),
(136, 1, '2021-06-13 07:45:09', '2021-06-13 07:45:09', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Hindi News</em></strong>.</p>\n<!-- /wp:paragraph -->', 'Hindi NEWS', '', 'publish', 'open', 'open', '', 'hindi-news', '', '', '2021-06-13 07:53:30', '2021-06-13 07:53:30', '', 0, 'http://localhost/wp/?p=136', 0, 'post', '', 0),
(137, 1, '2021-06-13 07:45:09', '2021-06-13 07:45:09', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Hindi News</em></strong>.</p>\n<!-- /wp:paragraph -->', 'Hindi NEWS', '', 'inherit', 'closed', 'closed', '', '136-revision-v1', '', '', '2021-06-13 07:45:09', '2021-06-13 07:45:09', '', 136, 'http://localhost/wp/?p=137', 0, 'revision', '', 0),
(138, 1, '2021-06-13 07:59:37', '2021-06-13 07:59:37', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em>Here you can watch Aajtak NEWS in Hindi.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\"><strong>You can touch this link than you can see the live Aajtak NEWS</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/6giviFF-Hck\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/6giviFF-Hck\n</div></figure>\n<!-- /wp:embed -->', 'Aajtak', '', 'publish', 'open', 'open', '', 'aajtak', '', '', '2021-06-13 07:59:37', '2021-06-13 07:59:37', '', 0, 'http://localhost/wp/?p=138', 0, 'post', '', 0),
(139, 1, '2021-06-13 07:59:37', '2021-06-13 07:59:37', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em>Here you can watch Aajtak NEWS in Hindi.</em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\"><strong>You can touch this link than you can see the live Aajtak NEWS</strong></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/6giviFF-Hck\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/6giviFF-Hck\n</div></figure>\n<!-- /wp:embed -->', 'Aajtak', '', 'inherit', 'closed', 'closed', '', '138-revision-v1', '', '', '2021-06-13 07:59:37', '2021-06-13 07:59:37', '', 138, 'http://localhost/wp/?p=139', 0, 'revision', '', 0),
(140, 1, '2021-06-13 08:03:52', '2021-06-13 08:03:52', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Marathi News</em></strong></p>\n<!-- /wp:paragraph -->', 'Marathi NEWS', '', 'publish', 'open', 'open', '', 'marathi-news', '', '', '2021-06-13 08:03:52', '2021-06-13 08:03:52', '', 0, 'http://localhost/wp/?p=140', 0, 'post', '', 0),
(141, 1, '2021-06-13 08:03:16', '2021-06-13 08:03:16', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Marathi News</em></strong></p>\n<!-- /wp:paragraph -->', 'Marathi NEWS', '', 'inherit', 'closed', 'closed', '', '140-autosave-v1', '', '', '2021-06-13 08:03:16', '2021-06-13 08:03:16', '', 140, 'http://localhost/wp/?p=141', 0, 'revision', '', 0),
(142, 1, '2021-06-13 08:03:52', '2021-06-13 08:03:52', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Marathi News</em></strong></p>\n<!-- /wp:paragraph -->', 'Marathi NEWS', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2021-06-13 08:03:52', '2021-06-13 08:03:52', '', 140, 'http://localhost/wp/?p=142', 0, 'revision', '', 0),
(143, 1, '2021-06-13 08:08:31', '2021-06-13 08:08:31', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch ABP Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Marathi live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/I6zGBF72o7M\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/I6zGBF72o7M\n</div></figure>\n<!-- /wp:embed -->', 'ABP Marathi', '', 'publish', 'open', 'open', '', 'abp-marathi', '', '', '2021-06-13 08:14:25', '2021-06-13 08:14:25', '', 0, 'http://localhost/wp/?p=143', 0, 'post', '', 0),
(144, 1, '2021-06-13 08:08:13', '2021-06-13 08:08:13', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch ABP Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Marathi live NEWS.</p>\n<!-- /wp:paragraph -->', 'ABP Marathi', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2021-06-13 08:08:13', '2021-06-13 08:08:13', '', 143, 'http://localhost/wp/?p=144', 0, 'revision', '', 0),
(145, 1, '2021-06-13 08:12:18', '2021-06-13 08:12:18', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch TV9 Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the TV9 Marathi live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/-Ku6BOxFIkc\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/-Ku6BOxFIkc\n</div></figure>\n<!-- /wp:embed -->', 'TV9 Marathi', '', 'publish', 'open', 'open', '', 'tv9-marathi', '', '', '2021-06-13 08:26:40', '2021-06-13 08:26:40', '', 0, 'http://localhost/wp/?p=145', 0, 'post', '', 0),
(146, 1, '2021-06-13 08:12:18', '2021-06-13 08:12:18', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch TV9 Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the TV9 Marathi live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/-Ku6BOxFIkc\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/-Ku6BOxFIkc\n</div></figure>\n<!-- /wp:embed -->', 'TV9 Marathi', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2021-06-13 08:12:18', '2021-06-13 08:12:18', '', 145, 'http://localhost/wp/?p=146', 0, 'revision', '', 0),
(148, 1, '2021-06-13 08:14:25', '2021-06-13 08:14:25', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch ABP Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Marathi live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/I6zGBF72o7M\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/I6zGBF72o7M\n</div></figure>\n<!-- /wp:embed -->', 'ABP Marathi', '', 'inherit', 'closed', 'closed', '', '143-revision-v1', '', '', '2021-06-13 08:14:25', '2021-06-13 08:14:25', '', 143, 'http://localhost/wp/?p=148', 0, 'revision', '', 0),
(153, 1, '2021-06-13 08:19:57', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2021-06-13 08:19:57', '0000-00-00 00:00:00', '', 3, 'http://localhost/wp/?p=153', 1, 'nav_menu_item', '', 0),
(159, 1, '2021-06-13 08:31:57', '2021-06-13 08:31:35', ' ', '', '', 'publish', 'closed', 'closed', '', '159', '', '', '2021-06-13 08:31:57', '2021-06-13 08:31:57', '', 0, 'http://localhost/wp/?p=159', 1, 'nav_menu_item', '', 0),
(160, 1, '2021-06-13 08:31:57', '2021-06-13 08:31:36', ' ', '', '', 'publish', 'closed', 'closed', '', '160', '', '', '2021-06-13 08:31:57', '2021-06-13 08:31:57', '', 6, 'http://localhost/wp/?p=160', 2, 'nav_menu_item', '', 0),
(161, 1, '2021-06-13 08:31:57', '2021-06-13 08:31:36', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2021-06-13 08:31:57', '2021-06-13 08:31:57', '', 0, 'http://localhost/wp/?p=161', 3, 'nav_menu_item', '', 0),
(162, 1, '2021-06-13 08:31:57', '2021-06-13 08:31:36', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2021-06-13 08:31:57', '2021-06-13 08:31:57', '', 3, 'http://localhost/wp/?p=162', 4, 'nav_menu_item', '', 0),
(163, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:37', ' ', '', '', 'publish', 'closed', 'closed', '', '163', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 3, 'http://localhost/wp/?p=163', 5, 'nav_menu_item', '', 0),
(164, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:37', ' ', '', '', 'publish', 'closed', 'closed', '', '164', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 0, 'http://localhost/wp/?p=164', 6, 'nav_menu_item', '', 0),
(165, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:37', ' ', '', '', 'publish', 'closed', 'closed', '', '165', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 2, 'http://localhost/wp/?p=165', 7, 'nav_menu_item', '', 0),
(166, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:38', ' ', '', '', 'publish', 'closed', 'closed', '', '166', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 0, 'http://localhost/wp/?p=166', 8, 'nav_menu_item', '', 0),
(167, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:38', ' ', '', '', 'publish', 'closed', 'closed', '', '167', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 15, 'http://localhost/wp/?p=167', 9, 'nav_menu_item', '', 0),
(168, 1, '2021-06-13 08:31:58', '2021-06-13 08:31:38', ' ', '', '', 'publish', 'closed', 'closed', '', '168', '', '', '2021-06-13 08:31:58', '2021-06-13 08:31:58', '', 15, 'http://localhost/wp/?p=168', 10, 'nav_menu_item', '', 0),
(170, 1, '2021-06-13 08:37:47', '2021-06-13 08:37:47', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><strong><em>Here you can watch the Hindi News</em></strong>.</p>\n<!-- /wp:paragraph -->', 'Hindi NEWS', '', 'inherit', 'closed', 'closed', '', '136-autosave-v1', '', '', '2021-06-13 08:37:47', '2021-06-13 08:37:47', '', 136, 'http://localhost/wp/?p=170', 0, 'revision', '', 0),
(171, 1, '2021-06-13 08:48:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-13 08:48:29', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=171', 0, 'post', '', 0),
(172, 1, '2021-06-13 08:54:52', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2021-06-13 08:54:52', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp/?p=172', 0, 'post', '', 0),
(173, 1, '2021-06-13 08:56:12', '2021-06-13 08:56:12', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":36}}} -->\n<p style=\"font-size:36px\"><strong><em>Welcome to Ganesha for NEWS</em></strong></p>\n<!-- /wp:paragraph -->', 'Ganesha', '', 'inherit', 'closed', 'closed', '', '87-autosave-v1', '', '', '2021-06-13 08:56:12', '2021-06-13 08:56:12', '', 87, 'http://localhost/wp/?p=173', 0, 'revision', '', 0),
(174, 1, '2021-06-13 09:46:33', '2021-06-13 09:46:33', '<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":38}}} -->\n<p style=\"font-size:38px\"><em><strong>Here You can watch ABP Marathi NEWS.</strong></em></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph {\"fontSize\":\"large\"} -->\n<p class=\"has-large-font-size\">When you click on this then you can watch the ABP Marathi live NEWS.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:embed {\"url\":\"https://youtu.be/I6zGBF72o7M\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"responsive\":true,\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->\n<figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\"><div class=\"wp-block-embed__wrapper\">\nhttps://youtu.be/I6zGBF72o7M\n</div></figure>\n<!-- /wp:embed -->', 'ABP Marathi', '', 'inherit', 'closed', 'closed', '', '143-autosave-v1', '', '', '2021-06-13 09:46:33', '2021-06-13 09:46:33', '', 143, 'http://localhost/wp/?p=174', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ap_termmeta`
--

CREATE TABLE `ap_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ap_terms`
--

CREATE TABLE `ap_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_terms`
--

INSERT INTO `ap_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Hindi News', 'news', 0),
(3, 'Gujarati News', 'gujarati', 0),
(6, 'Bangali News', 'bangali-news', 0),
(9, 'TV9', 'tv9', 0),
(10, 'TV9', 'tv9-gujarati', 0),
(11, 'ABP', 'abp', 0),
(12, 'ABP', 'abp-bangali-news', 0),
(13, 'Aajtak', 'aajtak', 0),
(15, 'Marathi News', 'marathi-news', 0),
(16, 'ABP', 'abp-marathi-news', 0),
(17, 'TV9', 'tv9-marathi-news', 0),
(25, 'MENU', 'menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ap_term_relationships`
--

CREATE TABLE `ap_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_term_relationships`
--

INSERT INTO `ap_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 1, 0),
(25, 3, 0),
(25, 10, 0),
(25, 11, 0),
(85, 1, 0),
(122, 6, 0),
(128, 12, 0),
(130, 3, 0),
(132, 11, 0),
(134, 10, 0),
(136, 2, 0),
(138, 13, 0),
(140, 15, 0),
(143, 16, 0),
(145, 17, 0),
(159, 25, 0),
(160, 25, 0),
(161, 25, 0),
(162, 25, 0),
(163, 25, 0),
(164, 25, 0),
(165, 25, 0),
(166, 25, 0),
(167, 25, 0),
(168, 25, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ap_term_taxonomy`
--

CREATE TABLE `ap_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_term_taxonomy`
--

INSERT INTO `ap_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 1),
(3, 3, 'category', '', 0, 1),
(6, 6, 'category', '', 0, 1),
(9, 9, 'category', '', 0, 0),
(10, 10, 'category', '', 3, 1),
(11, 11, 'category', '', 3, 1),
(12, 12, 'category', '', 6, 1),
(13, 13, 'category', '', 2, 1),
(15, 15, 'category', '', 0, 1),
(16, 16, 'category', '', 15, 1),
(17, 17, 'category', '', 15, 1),
(25, 25, 'nav_menu', '', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ap_usermeta`
--

CREATE TABLE `ap_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT 0,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_usermeta`
--

INSERT INTO `ap_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'ruchi_2212@'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'true'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'ap_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'ap_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:6:{s:64:\"0126a22290bf6264db4d0d48f03d1ba8414dd33ff49fbc76fe319dc048845db1\";a:4:{s:10:\"expiration\";i:1623588681;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623415881;}s:64:\"594d65e7144b7599d8304c951cd9daa6d33e2658a5f708c4170deaf7b0065129\";a:4:{s:10:\"expiration\";i:1623588801;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623416001;}s:64:\"ab477f9b35d49e5b3320550908e572fa44012729b094a4a6a15d7136bbf620b6\";a:4:{s:10:\"expiration\";i:1624705254;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623495654;}s:64:\"6a9646cd2f477b8f757528d477cac224767636d7eb4cbdc3d9da736154fc3e89\";a:4:{s:10:\"expiration\";i:1624708754;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623499154;}s:64:\"6c7806df49fb5c59495eb4b5c05b36f629cc69d666ca075d6e91b7b6dd57e980\";a:4:{s:10:\"expiration\";i:1623679510;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623506710;}s:64:\"4736105de6414b68c9cd097c628af64e9f4ce1c78752a29746d751aa29af2350\";a:4:{s:10:\"expiration\";i:1623734287;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:114:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Safari/537.36\";s:5:\"login\";i:1623561487;}}'),
(17, 1, 'ap_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'ap_user-settings', 'libraryContent=browse&mfold=o&posts_list_mode=list'),
(19, 1, 'ap_user-settings-time', '1623573803'),
(20, 1, 'edit_category_per_page', '20'),
(21, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";i:4;s:15:\"title-attribute\";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(23, 1, 'enjoynews_notice_ignore', 'true'),
(24, 1, 'nav_menu_recently_edited', '25'),
(25, 1, 'meta-box-order_page', 'a:3:{s:4:\"side\";s:36:\"pageparentdiv,submitdiv,postimagediv\";s:6:\"normal\";s:57:\"postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv\";s:8:\"advanced\";s:0:\"\";}'),
(26, 1, 'screen_layout_page', '2'),
(27, 1, 'edit_post_per_page', '200');

-- --------------------------------------------------------

--
-- Table structure for table `ap_users`
--

CREATE TABLE `ap_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ap_users`
--

INSERT INTO `ap_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'ruchi_2212@', '$P$BBYxmbKsrUDwYyjEg50z8MG5J/WVpF0', 'ruchi_2212', 'ruchipatel3170@gmail.com', 'http://localhost/wp', '2021-06-11 12:50:59', '', 0, 'ruchi_2212@');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ap_commentmeta`
--
ALTER TABLE `ap_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `ap_comments`
--
ALTER TABLE `ap_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `ap_links`
--
ALTER TABLE `ap_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `ap_options`
--
ALTER TABLE `ap_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Indexes for table `ap_postmeta`
--
ALTER TABLE `ap_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `ap_posts`
--
ALTER TABLE `ap_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `ap_termmeta`
--
ALTER TABLE `ap_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `ap_terms`
--
ALTER TABLE `ap_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `ap_term_relationships`
--
ALTER TABLE `ap_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `ap_term_taxonomy`
--
ALTER TABLE `ap_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `ap_usermeta`
--
ALTER TABLE `ap_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `ap_users`
--
ALTER TABLE `ap_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ap_commentmeta`
--
ALTER TABLE `ap_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ap_comments`
--
ALTER TABLE `ap_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ap_links`
--
ALTER TABLE `ap_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ap_options`
--
ALTER TABLE `ap_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=322;

--
-- AUTO_INCREMENT for table `ap_postmeta`
--
ALTER TABLE `ap_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=940;

--
-- AUTO_INCREMENT for table `ap_posts`
--
ALTER TABLE `ap_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `ap_termmeta`
--
ALTER TABLE `ap_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ap_terms`
--
ALTER TABLE `ap_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `ap_term_taxonomy`
--
ALTER TABLE `ap_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `ap_usermeta`
--
ALTER TABLE `ap_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ap_users`
--
ALTER TABLE `ap_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
